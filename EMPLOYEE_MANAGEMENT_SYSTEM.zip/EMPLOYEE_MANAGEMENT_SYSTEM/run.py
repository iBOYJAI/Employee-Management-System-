import sys

from app import create_app, db
from app.models import (
    User,
    Employee,
    Department,
    Role,
    LeaveType,
    Setting,
    Attendance,
    Leave,
    Payroll,
    PayrollItem,
    PerformanceReview,
    Goal,
    Notification,
)
from datetime import date, datetime, timedelta
from sqlalchemy.exc import OperationalError
from sqlalchemy import text
from flask import url_for

app = create_app()


def verify_db_connection():
    """Fail fast with a clear hint when MySQL is unreachable."""
    try:
        db.session.execute(text("SELECT 1"))
        return True
    except OperationalError as exc:
        print("\n[Database] Unable to connect to MySQL.")
        print("Tips: ensure MySQL is running (e.g., start via XAMPP),")
        print("      confirm host/user/password/database in config.py or .env,")
        print("      and that port 3306 is open.")
        print(f"Original error: {exc}\n")
        return False


def ensure_default_admin():
    """Ensure a default admin user exists with known credentials."""
    admin = User.query.filter_by(username='admin').first()
    admin_employee = None
    # Ensure base department/role for admin
    dept = Department.query.filter_by(name='IT').first() or Department(name='IT', description='Information Technology Department')
    role = Role.query.filter_by(name='Administrator').first() or Role(name='Administrator', description='System administrator')
    if dept.id is None:
        db.session.add(dept)
        db.session.flush()
    if role.id is None:
        db.session.add(role)
        db.session.flush()

    if not admin:
        admin = User(username='admin', email='admin@company.com', role='Admin')
        admin.set_password('admin123')
        admin.is_active = True
        db.session.add(admin)
        db.session.commit()
        print("Default admin user created: username='admin', password='admin123'")
    else:
        # Reset to known credentials to avoid bad/placeholder hashes from imports
        admin.email = admin.email or 'admin@company.com'
        admin.role = 'Admin'
        admin.is_active = True
        admin.set_password('admin123')
        db.session.commit()
        print("Default admin user reset: username='admin', password='admin123'")

    # Ensure admin has an employee profile for attendance/payroll
    admin_employee = admin.employee
    if not admin_employee:
        admin_employee = Employee(
            employee_id='EMPADMIN0001',
            first_name='System',
            last_name='Administrator',
            email=admin.email,
            department_id=dept.id,
            role_id=role.id,
            hire_date=date(2023, 1, 1),
            employment_type='Full-time',
            status='Active',
            base_salary=90000,
            currency='INR'
        )
        db.session.add(admin_employee)
        db.session.flush()
        admin.employee_id = admin_employee.id
        db.session.commit()


def ensure_demo_users():
    """Ensure demo HR/Manager/Employee users exist with known credentials."""
    demos = [
        ('sarah.johnson', 'sarah.johnson@company.com', 'HR'),
        ('john.smith', 'john.smith@company.com', 'Manager'),
        ('michael.brown', 'michael.brown@company.com', 'Employee'),
    ]
    for username, email, role in demos:
        user = User.query.filter_by(username=username).first()
        if not user:
            user = User(username=username, email=email, role=role)
            user.set_password('password123')
            user.is_active = True
            db.session.add(user)
        else:
            user.email = user.email or email
            user.role = role
            user.is_active = True
            user.set_password('password123')
    db.session.commit()


def ensure_demo_employees():
    """Create demo employee profiles and link to demo users."""
    dept_by_name = {d.name: d for d in Department.query.all()}
    role_by_name = {r.name: r for r in Role.query.all()}

    def get_or_create_dept(name, desc=''):
        dept = dept_by_name.get(name)
        if not dept:
            dept = Department(name=name, description=desc)
            db.session.add(dept)
            db.session.flush()
            dept_by_name[name] = dept
        return dept

    def get_or_create_role(name, desc=''):
        role = role_by_name.get(name)
        if not role:
            role = Role(name=name, description=desc)
            db.session.add(role)
            db.session.flush()
            role_by_name[name] = role
        return role

    demos = [
        ('sarah.johnson', 'EMP20250002', 'Sarah', 'Johnson', 'HR', 'HR Manager', None, 85000),
        ('john.smith', 'EMP20250003', 'John', 'Smith', 'Operations', 'Project Manager', 'sarah.johnson', 90000),
        ('michael.brown', 'EMP20250004', 'Michael', 'Brown', 'IT', 'Software Developer', 'john.smith', 70000),
    ]

    created = {}
    for username, emp_code, first, last, dept_name, role_name, manager_username, salary in demos:
        user = User.query.filter_by(username=username).first()
        # Reuse existing employee by code if present
        employee = Employee.query.filter_by(employee_id=emp_code).first()
        dept = get_or_create_dept(dept_name, f'{dept_name} Department')
        role = get_or_create_role(role_name, role_name)

        if not employee:
            employee = Employee(
                employee_id=emp_code,
                first_name=first,
                last_name=last,
                email=user.email if user else f'{username}@company.com',
                department_id=dept.id,
                role_id=role.id,
                hire_date=date(2023, 1, 15),
                employment_type='Full-time',
                status='Active',
                base_salary=salary,
                currency='INR'
            )
            db.session.add(employee)
            db.session.flush()

        created[username] = employee
        if user:
            user.employee_id = employee.id
            user.role = user.role or role_name
            user.is_active = True
            # ensure email if missing
            user.email = user.email or f'{username}@company.com'

    db.session.commit()

    # Assign managers after all employees exist
    for username, _, _, _, _, _, manager_username, _ in demos:
        if manager_username and manager_username in created and username in created:
            created[username].manager_id = created[manager_username].id
    db.session.commit()


def seed_mock_data():
    """Seed lightweight demo data for attendance, leaves, and payroll."""
    employees = Employee.query.all()
    if not employees:
        return

    today = date.today()

    # Attendance last 5 days
    for emp in employees:
        for i in range(5):
            day = today - timedelta(days=i)
            existing = Attendance.query.filter_by(employee_id=emp.id, date=day).first()
            if not existing:
                att = Attendance(
                    employee_id=emp.id,
                    date=day,
                    check_in=datetime(day.year, day.month, day.day, 9, 0).time(),
                    check_out=datetime(day.year, day.month, day.day, 17, 30).time(),
                    hours_worked=8.5,
                    status='Present'
                )
                db.session.add(att)

    # Demo leaves for first two employees
    lt = LeaveType.query.first()
    if employees and lt:
        for emp in employees[:2]:
            existing_leave = Leave.query.filter_by(employee_id=emp.id).first()
            if not existing_leave:
                start = today + timedelta(days=3)
                end = start + timedelta(days=2)
                leave = Leave(
                    employee_id=emp.id,
                    leave_type_id=lt.id,
                    start_date=start,
                    end_date=end,
                    days=3,
                    reason='Personal',
                    status='Approved',
                    approved_by=emp.id,
                    approved_at=datetime.utcnow()
                )
                db.session.add(leave)

    # Payroll for current and previous month
    for emp in employees:
        for offset in range(0, 2):
            month = today.month - offset
            year = today.year
            if month <= 0:
                month += 12
                year -= 1
            start = date(year, month, 1)
            next_month = date(year + (month // 12), (month % 12) + 1, 1)
            end = next_month - timedelta(days=1)

            existing_payroll = Payroll.query.filter_by(
                employee_id=emp.id,
                pay_period_start=start,
                pay_period_end=end
            ).first()
            if not existing_payroll:
                base_salary = float(emp.base_salary or 60000)
                tax_rate = 0.15
                tax_amount = base_salary * tax_rate
                payroll = Payroll(
                    employee_id=emp.id,
                    pay_period_start=start,
                    pay_period_end=end,
                    pay_date=today,
                    base_salary=base_salary,
                    gross_salary=base_salary,
                    total_deductions=tax_amount,
                    net_salary=base_salary - tax_amount,
                    status='Processed'
                )
                db.session.add(payroll)
                db.session.flush()
                db.session.add(PayrollItem(
                    payroll_id=payroll.id,
                    item_type='Earning',
                    name='Base Salary',
                    amount=base_salary
                ))
                db.session.add(PayrollItem(
                    payroll_id=payroll.id,
                    item_type='Deduction',
                    name='Income Tax',
                    amount=tax_amount
                ))

    db.session.commit()

    # Performance reviews and goals
    for emp in employees[:3]:
        reviewer = emp.manager or employees[0]
        pr_existing = PerformanceReview.query.filter_by(employee_id=emp.id).first()
        if not pr_existing:
            pr = PerformanceReview(
                employee_id=emp.id,
                reviewer_id=reviewer.id if reviewer else emp.id,
                review_period_start=date(today.year, today.month, 1),
                review_period_end=today,
                overall_rating=4.2,
                feedback='Solid performance with consistent delivery.',
                goals_achieved=3,
                goals_total=4,
                status='Completed'
            )
            db.session.add(pr)
        goal_existing = Goal.query.filter_by(employee_id=emp.id).first()
        if not goal_existing:
            g = Goal(
                employee_id=emp.id,
                title='Improve code quality',
                description='Reduce production bugs by 30%',
                target_date=today + timedelta(days=90),
                status='In Progress',
                progress=40
            )
            db.session.add(g)

    # Notifications demo
    for emp in employees[:3]:
        if emp.user_account:
            user_obj = emp.user_account[0] if hasattr(emp.user_account, '__iter__') else emp.user_account
            existing_note = Notification.query.filter_by(user_id=user_obj.id).first()
            if not existing_note:
                note = Notification(
                    user_id=user_obj.id,
                    title='Welcome',
                    message='Your account has been set up with demo data.',
                    type='info',
                    link='/dashboard'
                )
                db.session.add(note)

    db.session.commit()


def create_tables():
    """Create database tables and default data."""
    db.create_all()
    
    # Create default departments if not exists
    if Department.query.count() == 0:
        departments = [
            Department(name='IT', description='Information Technology Department'),
            Department(name='HR', description='Human Resources Department'),
            Department(name='Finance', description='Finance and Accounting Department'),
            Department(name='Operations', description='Operations Department'),
            Department(name='Sales', description='Sales and Marketing Department')
        ]
        for dept in departments:
            db.session.add(dept)
    
    # Create default roles if not exists
    if Role.query.count() == 0:
        roles = [
            Role(name='Software Developer', description='Develops and maintains software applications'),
            Role(name='HR Manager', description='Manages human resources operations'),
            Role(name='Project Manager', description='Manages projects and teams'),
            Role(name='Accountant', description='Handles financial records and payroll'),
            Role(name='Administrator', description='System administrator')
        ]
        for role in roles:
            db.session.add(role)
    
    # Create default leave types if not exists
    if LeaveType.query.count() == 0:
        leave_types = [
            LeaveType(name='Annual Leave', max_days=20, is_paid=True, description='Annual vacation leave'),
            LeaveType(name='Sick Leave', max_days=10, is_paid=True, description='Medical leave'),
            LeaveType(name='Personal Leave', max_days=5, is_paid=False, description='Personal time off'),
            LeaveType(name='Maternity Leave', max_days=90, is_paid=True, description='Maternity leave'),
            LeaveType(name='Paternity Leave', max_days=7, is_paid=True, description='Paternity leave'),
            LeaveType(name='Emergency Leave', max_days=3, is_paid=False, description='Emergency situations')
        ]
        for lt in leave_types:
            db.session.add(lt)
    
    # Create default settings if not exists
    if Setting.query.count() == 0:
        settings = [
            Setting(key='company_name', value='Employee Management System', description='Company name'),
            Setting(key='company_address', value='123 Business Street, City, Country', description='Company address'),
            Setting(key='company_phone', value='+1-234-567-8900', description='Company phone number'),
            Setting(key='company_email', value='info@company.com', description='Company email'),
            Setting(key='fiscal_year_start', value='2024-01-01', description='Fiscal year start date'),
            Setting(key='working_hours_per_day', value='8', description='Standard working hours per day'),
            Setting(key='tax_rate', value='0.15', description='Default tax rate (15%)')
        ]
        for setting in settings:
            db.session.add(setting)
    
    db.session.commit()

if __name__ == '__main__':
    with app.app_context():
        if not verify_db_connection():
            sys.exit(1)

        create_tables()
        ensure_default_admin()
        ensure_demo_users()
        ensure_demo_employees()
        seed_mock_data()
    
    app.run(debug=True, host='127.0.0.1', port=5000)

