from flask import Flask, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from pathlib import Path
from dotenv import load_dotenv
import os
from flask import send_from_directory
from config import Config

db = SQLAlchemy()
login_manager = LoginManager()

def create_app(config_class=Config):
    # Load environment variables from project root .env if present
    project_root = Path(__file__).resolve().parent.parent
    load_dotenv(project_root / '.env')

    # Point Flask to the project-level templates/static folders
    app = Flask(
        __name__,
        template_folder='../templates',
        static_folder='../static'
    )
    app.config.from_object(config_class)
    
    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'info'
    
    # Common template globals
    from datetime import date, datetime
    from flask import request, url_for
    @app.context_processor
    def inject_globals():
        def get_profile_pic_url(employee):
            """Helper function to get profile picture URL"""
            if employee and employee.profile_picture:
                from flask import url_for
                return url_for('employees.uploaded_file', filename=employee.profile_picture)
            return url_for('static', filename='icons/user.png')
        
        return {
            'date': date,
            'datetime': datetime,
            'back_url': request.referrer or url_for('dashboard.index'),
            'get_profile_pic_url': get_profile_pic_url
        }

    @app.template_filter('inr')
    def format_inr(value):
        try:
            return f"₹{float(value):,.2f}"
        except Exception:
            return value
    
    # Create upload directories
    os.makedirs(app.config['UPLOAD_FOLDER'] / 'documents', exist_ok=True)
    os.makedirs(app.config['UPLOAD_FOLDER'] / 'profile_pics', exist_ok=True)
    
    # Register blueprints
    from app.blueprints.auth import bp as auth_bp
    app.register_blueprint(auth_bp, url_prefix='/auth')
    
    from app.blueprints.dashboard import bp as dashboard_bp
    app.register_blueprint(dashboard_bp, url_prefix='/dashboard')
    
    from app.blueprints.employees import bp as employees_bp
    app.register_blueprint(employees_bp, url_prefix='/employees')
    
    from app.blueprints.attendance import bp as attendance_bp
    app.register_blueprint(attendance_bp, url_prefix='/attendance')
    
    from app.blueprints.leaves import bp as leaves_bp
    app.register_blueprint(leaves_bp, url_prefix='/leaves')
    
    from app.blueprints.payroll import bp as payroll_bp
    app.register_blueprint(payroll_bp, url_prefix='/payroll')
    
    from app.blueprints.performance import bp as performance_bp
    app.register_blueprint(performance_bp, url_prefix='/performance')
    
    from app.blueprints.assets import bp as assets_bp
    app.register_blueprint(assets_bp, url_prefix='/assets')
    
    from app.blueprints.training import bp as training_bp
    app.register_blueprint(training_bp, url_prefix='/training')
    
    from app.blueprints.reports import bp as reports_bp
    app.register_blueprint(reports_bp, url_prefix='/reports')
    
    from app.blueprints.notifications import bp as notifications_bp
    app.register_blueprint(notifications_bp, url_prefix='/notifications')
    
    from app.blueprints.settings import bp as settings_bp
    app.register_blueprint(settings_bp, url_prefix='/settings')
    
    # Root route
    @app.route('/')
    def index():
        from flask_login import current_user
        if current_user.is_authenticated:
            return redirect(url_for('dashboard.index'))
        return redirect(url_for('auth.login'))

    @app.route('/favicon.ico')
    def favicon():
        static_dir = Path(__file__).resolve().parent.parent / 'static'
        icon_path = static_dir / 'favicon.ico'
        if icon_path.exists():
            return send_from_directory(static_dir, 'favicon.ico')
        # Fallback to an existing icon
        return send_from_directory(static_dir / 'icons', 'user.png')
    
    # Import models for Flask-Login
    from app.models import User
    
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))
    
    # Error handlers
    @app.errorhandler(404)
    def not_found_error(error):
        return render_template('errors/404.html'), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template('errors/500.html'), 500
    
    return app
