from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.pdfgen import canvas
from datetime import datetime
import os

# Professional color scheme
PRIMARY_COLOR = colors.HexColor('#2563EB')
SECONDARY_COLOR = colors.HexColor('#1E40AF')
ACCENT_COLOR = colors.HexColor('#3B82F6')
SUCCESS_COLOR = colors.HexColor('#10B981')
WARNING_COLOR = colors.HexColor('#F59E0B')
DANGER_COLOR = colors.HexColor('#EF4444')
LIGHT_BG = colors.HexColor('#F3F4F6')
BORDER_COLOR = colors.HexColor('#E5E7EB')

def format_currency(amount):
    """Format amount as INR currency"""
    return f"₹{amount:,.2f}"

def make_header_footer(title="Employee Management System"):
    """Create header/footer function with page counter"""
    page_num = [0]
    
    def add_header_footer(canvas_obj, doc):
        page_num[0] += 1
        canvas_obj.saveState()
        
        # Header
        canvas_obj.setFillColor(PRIMARY_COLOR)
        canvas_obj.rect(0, A4[1] - 0.8*inch, A4[0], 0.8*inch, fill=1)
        canvas_obj.setFillColor(colors.white)
        canvas_obj.setFont("Helvetica-Bold", 16)
        canvas_obj.drawString(0.5*inch, A4[1] - 0.5*inch, title)
        
        # Footer
        canvas_obj.setFillColor(LIGHT_BG)
        canvas_obj.rect(0, 0, A4[0], 0.6*inch, fill=1)
        canvas_obj.setFillColor(colors.grey)
        canvas_obj.setFont("Helvetica", 8)
        footer_text = f"Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Page {page_num[0]}"
        canvas_obj.drawCentredString(A4[0]/2, 0.3*inch, footer_text)
        
        canvas_obj.restoreState()
    
    return add_header_footer

def generate_payslip_pdf(payroll_data, employee_data, output_path):
    """Generate payslip PDF"""
    doc = SimpleDocTemplate(output_path, pagesize=A4, 
                           rightMargin=0.5*inch, leftMargin=0.5*inch,
                           topMargin=1*inch, bottomMargin=0.8*inch)
    story = []
    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=28,
        textColor=PRIMARY_COLOR,
        spaceAfter=20,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    heading_style = ParagraphStyle(
        'SectionHeading',
        parent=styles['Heading2'],
        fontSize=14,
        textColor=SECONDARY_COLOR,
        spaceAfter=12,
        spaceBefore=12,
        fontName='Helvetica-Bold'
    )
    
    # Title
    story.append(Paragraph("PAYSLIP", title_style))
    story.append(Spacer(1, 0.3*inch))
    
    # Employee Info
    info_data = [
        ['Employee Name:', employee_data.get('full_name', 'N/A')],
        ['Employee ID:', employee_data.get('employee_id', 'N/A')],
        ['Department:', employee_data.get('department', 'N/A')],
        ['Pay Period:', f"{payroll_data['pay_period_start']} to {payroll_data['pay_period_end']}"],
        ['Pay Date:', str(payroll_data['pay_date'])],
    ]
    
    info_table = Table(info_data, colWidths=[2.5*inch, 4*inch])
    info_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), LIGHT_BG),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('GRID', (0, 0), (-1, -1), 1, BORDER_COLOR),
        ('ROWBACKGROUNDS', (0, 0), (-1, -1), [colors.white, LIGHT_BG])
    ]))
    story.append(info_table)
    story.append(Spacer(1, 0.4*inch))
    
    # Earnings
    earnings_data = [['Earnings', 'Amount']]
    total_earnings = 0
    for item in payroll_data.get('earnings', []):
        earnings_data.append([item['name'], format_currency(item['amount'])])
        total_earnings += item['amount']
    
    earnings_table = Table(earnings_data, colWidths=[4.5*inch, 2*inch])
    earnings_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), PRIMARY_COLOR),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('GRID', (0, 0), (-1, -1), 1, BORDER_COLOR),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT_BG])
    ]))
    story.append(Paragraph("Earnings", heading_style))
    story.append(earnings_table)
    story.append(Spacer(1, 0.3*inch))
    
    # Deductions
    deductions_data = [['Deductions', 'Amount']]
    total_deductions = 0
    for item in payroll_data.get('deductions', []):
        deductions_data.append([item['name'], format_currency(item['amount'])])
        total_deductions += item['amount']
    
    deductions_table = Table(deductions_data, colWidths=[4.5*inch, 2*inch])
    deductions_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), DANGER_COLOR),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('GRID', (0, 0), (-1, -1), 1, BORDER_COLOR),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT_BG])
    ]))
    story.append(Paragraph("Deductions", heading_style))
    story.append(deductions_table)
    story.append(Spacer(1, 0.4*inch))
    
    # Summary
    summary_data = [
        ['Gross Salary:', format_currency(payroll_data.get('gross_salary', 0))],
        ['Total Deductions:', format_currency(total_deductions)],
        ['Net Salary:', format_currency(payroll_data.get('net_salary', 0))]
    ]
    
    summary_table = Table(summary_data, colWidths=[4.5*inch, 2*inch])
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0, -1), (-1, -1), SUCCESS_COLOR),
        ('TEXTCOLOR', (0, -1), (-1, -1), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 11),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('GRID', (0, 0), (-1, -1), 1, BORDER_COLOR),
        ('ROWBACKGROUNDS', (0, 0), (-1, -2), [colors.white, LIGHT_BG])
    ]))
    story.append(summary_table)
    
    header_footer = make_header_footer("PAYSLIP")
    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)
    return output_path

def generate_attendance_report_pdf(records, start_date, end_date, stats, output_path):
    """Generate professional attendance report PDF"""
    doc = SimpleDocTemplate(output_path, pagesize=A4,
                           rightMargin=0.5*inch, leftMargin=0.5*inch,
                           topMargin=1*inch, bottomMargin=0.8*inch)
    story = []
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle('Title', parent=styles['Heading1'],
                                 fontSize=24, textColor=PRIMARY_COLOR,
                                 spaceAfter=10, alignment=TA_CENTER,
                                 fontName='Helvetica-Bold')
    
    subtitle_style = ParagraphStyle('Subtitle', parent=styles['Normal'],
                                    fontSize=11, textColor=colors.grey,
                                    alignment=TA_CENTER, spaceAfter=20)
    
    heading_style = ParagraphStyle('Heading', parent=styles['Heading2'],
                                   fontSize=14, textColor=SECONDARY_COLOR,
                                   spaceAfter=12, fontName='Helvetica-Bold')
    
    # Title
    story.append(Paragraph("ATTENDANCE REPORT", title_style))
    story.append(Paragraph(f"Period: {start_date} to {end_date}", subtitle_style))
    story.append(Spacer(1, 0.3*inch))
    
    # Summary Statistics
    summary_data = [
        [Paragraph('Total Days', styles['Normal']), Paragraph(str(stats.get('total_days', 0)), styles['Normal']),
         Paragraph('Present', styles['Normal']), Paragraph(str(stats.get('present_count', 0)), styles['Normal'])],
        [Paragraph('Absent', styles['Normal']), Paragraph(str(stats.get('absent_count', 0)), styles['Normal']),
         Paragraph('Attendance Rate', styles['Normal']), Paragraph(f"{stats.get('attendance_rate', 0):.1f}%", styles['Normal'])]
    ]
    
    summary_table = Table(summary_data, colWidths=[1.5*inch]*4)
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), PRIMARY_COLOR),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 11),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('GRID', (0, 0), (-1, -1), 1, BORDER_COLOR)
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 0.4*inch))
    
    # Attendance Records Table
    if records:
        story.append(Paragraph("Attendance Details", heading_style))
        table_data = [[
            Paragraph('Date', styles['Normal']),
            Paragraph('Employee', styles['Normal']),
            Paragraph('Check In', styles['Normal']),
            Paragraph('Check Out', styles['Normal']),
            Paragraph('Hours', styles['Normal']),
            Paragraph('Status', styles['Normal'])
        ]]
        
        for record in records:
            check_in = record.check_in.strftime('%H:%M') if record.check_in else '-'
            check_out = record.check_out.strftime('%H:%M') if record.check_out else '-'
            hours = f"{record.hours_worked:.2f}" if record.hours_worked else '-'
            status = record.status if record.status else 'Absent'
            
            table_data.append([
                Paragraph(record.date.strftime('%Y-%m-%d'), styles['Normal']),
                Paragraph(record.employee.full_name if record.employee else 'N/A', styles['Normal']),
                Paragraph(check_in, styles['Normal']),
                Paragraph(check_out, styles['Normal']),
                Paragraph(hours, styles['Normal']),
                Paragraph(status, styles['Normal'])
            ])
        
        # Split into pages if too many rows
        max_rows_per_page = 25
        for i in range(0, len(table_data), max_rows_per_page):
            if i > 0:
                story.append(PageBreak())
                story.append(Paragraph("Attendance Details (continued)", heading_style))
            
            page_data = table_data[0:1] + table_data[i+1:i+max_rows_per_page+1]
            table = Table(page_data, colWidths=[1*inch, 1.8*inch, 0.9*inch, 0.9*inch, 0.8*inch, 0.8*inch])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), PRIMARY_COLOR),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('ALIGN', (3, 0), (5, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('GRID', (0, 0), (-1, -1), 0.5, BORDER_COLOR),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT_BG])
            ]))
            story.append(table)
    else:
        story.append(Paragraph("No attendance records found for this period.", styles['Normal']))
    
    header_footer = make_header_footer("ATTENDANCE REPORT")
    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)
    return output_path

def generate_leave_summary_pdf(leaves, year, status_summary, output_path):
    """Generate professional leave summary PDF"""
    doc = SimpleDocTemplate(output_path, pagesize=A4,
                           rightMargin=0.5*inch, leftMargin=0.5*inch,
                           topMargin=1*inch, bottomMargin=0.8*inch)
    story = []
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle('Title', parent=styles['Heading1'],
                                 fontSize=24, textColor=PRIMARY_COLOR,
                                 spaceAfter=10, alignment=TA_CENTER,
                                 fontName='Helvetica-Bold')
    
    subtitle_style = ParagraphStyle('Subtitle', parent=styles['Normal'],
                                    fontSize=11, textColor=colors.grey,
                                    alignment=TA_CENTER, spaceAfter=20)
    
    heading_style = ParagraphStyle('Heading', parent=styles['Heading2'],
                                   fontSize=14, textColor=SECONDARY_COLOR,
                                   spaceAfter=12, fontName='Helvetica-Bold')
    
    # Title
    story.append(Paragraph("LEAVE SUMMARY REPORT", title_style))
    story.append(Paragraph(f"Year: {year}", subtitle_style))
    story.append(Spacer(1, 0.3*inch))
    
    # Status Summary
    if status_summary:
        story.append(Paragraph("Summary by Status", heading_style))
        summary_data = [[
            Paragraph('Status', styles['Normal']),
            Paragraph('Count', styles['Normal']),
            Paragraph('Total Days', styles['Normal'])
        ]]
        for status, data in status_summary.items():
            summary_data.append([
                Paragraph(status, styles['Normal']),
                Paragraph(str(data['count']), styles['Normal']),
                Paragraph(str(data['days']), styles['Normal'])
            ])
        
        summary_table = Table(summary_data, colWidths=[2.5*inch, 2*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), PRIMARY_COLOR),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('ALIGN', (1, 0), (2, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, BORDER_COLOR),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT_BG])
        ]))
        story.append(summary_table)
        story.append(Spacer(1, 0.4*inch))
    
    # Leave Details
    if leaves:
        story.append(Paragraph("Leave Details", heading_style))
        table_data = [[
            Paragraph('Employee', styles['Normal']),
            Paragraph('Leave Type', styles['Normal']),
            Paragraph('Start Date', styles['Normal']),
            Paragraph('End Date', styles['Normal']),
            Paragraph('Days', styles['Normal']),
            Paragraph('Status', styles['Normal'])
        ]]
        
        for leave in leaves:
            table_data.append([
                Paragraph(leave.employee.full_name if leave.employee else 'N/A', styles['Normal']),
                Paragraph(leave.leave_type.name if leave.leave_type else 'N/A', styles['Normal']),
                Paragraph(leave.start_date.strftime('%Y-%m-%d'), styles['Normal']),
                Paragraph(leave.end_date.strftime('%Y-%m-%d'), styles['Normal']),
                Paragraph(str(leave.days), styles['Normal']),
                Paragraph(leave.status, styles['Normal'])
            ])
        
        max_rows_per_page = 25
        for i in range(0, len(table_data), max_rows_per_page):
            if i > 0:
                story.append(PageBreak())
                story.append(Paragraph("Leave Details (continued)", heading_style))
            
            page_data = table_data[0:1] + table_data[i+1:i+max_rows_per_page+1]
            table = Table(page_data, colWidths=[1.5*inch, 1.2*inch, 1*inch, 1*inch, 0.8*inch, 1*inch])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), PRIMARY_COLOR),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('ALIGN', (2, 0), (5, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('GRID', (0, 0), (-1, -1), 0.5, BORDER_COLOR),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT_BG])
            ]))
            story.append(table)
    else:
        story.append(Paragraph("No leave records found for this year.", styles['Normal']))
    
    header_footer = make_header_footer("LEAVE SUMMARY REPORT")
    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)
    return output_path

def generate_payroll_summary_pdf(payrolls, month, year, totals, output_path):
    """Generate professional payroll summary PDF"""
    doc = SimpleDocTemplate(output_path, pagesize=A4,
                           rightMargin=0.5*inch, leftMargin=0.5*inch,
                           topMargin=1*inch, bottomMargin=0.8*inch)
    story = []
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle('Title', parent=styles['Heading1'],
                                 fontSize=24, textColor=PRIMARY_COLOR,
                                 spaceAfter=10, alignment=TA_CENTER,
                                 fontName='Helvetica-Bold')
    
    subtitle_style = ParagraphStyle('Subtitle', parent=styles['Normal'],
                                    fontSize=11, textColor=colors.grey,
                                    alignment=TA_CENTER, spaceAfter=20)
    
    heading_style = ParagraphStyle('Heading', parent=styles['Heading2'],
                                   fontSize=14, textColor=SECONDARY_COLOR,
                                   spaceAfter=12, fontName='Helvetica-Bold')
    
    month_names = ['', 'January', 'February', 'March', 'April', 'May', 'June',
                   'July', 'August', 'September', 'October', 'November', 'December']
    
    # Title
    story.append(Paragraph("PAYROLL SUMMARY REPORT", title_style))
    story.append(Paragraph(f"{month_names[month]} {year}", subtitle_style))
    story.append(Spacer(1, 0.3*inch))
    
    # Summary Totals
    summary_data = [
        [Paragraph('Total Gross Salary', styles['Normal']), Paragraph(format_currency(totals.get('total_gross', 0)), styles['Normal'])],
        [Paragraph('Total Deductions', styles['Normal']), Paragraph(format_currency(totals.get('total_deductions', 0)), styles['Normal'])],
        [Paragraph('Total Net Salary', styles['Normal']), Paragraph(format_currency(totals.get('total_net', 0)), styles['Normal'])]
    ]
    
    summary_table = Table(summary_data, colWidths=[3*inch, 3*inch])
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), SUCCESS_COLOR),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 12),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('GRID', (0, 0), (-1, -1), 1, BORDER_COLOR)
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 0.4*inch))
    
    # Payroll Details
    if payrolls:
        story.append(Paragraph("Payroll Details", heading_style))
        table_data = [[
            Paragraph('Employee', styles['Normal']),
            Paragraph('Pay Period', styles['Normal']),
            Paragraph('Gross Salary', styles['Normal']),
            Paragraph('Deductions', styles['Normal']),
            Paragraph('Net Salary', styles['Normal']),
            Paragraph('Status', styles['Normal'])
        ]]
        
        for payroll in payrolls:
            period = f"{payroll.pay_period_start.strftime('%d/%m/%Y')} to {payroll.pay_period_end.strftime('%d/%m/%Y')}"
            table_data.append([
                Paragraph(payroll.employee.full_name if payroll.employee else 'N/A', styles['Normal']),
                Paragraph(period, styles['Normal']),
                Paragraph(format_currency(float(payroll.gross_salary)), styles['Normal']),
                Paragraph(format_currency(float(payroll.total_deductions)), styles['Normal']),
                Paragraph(format_currency(float(payroll.net_salary)), styles['Normal']),
                Paragraph(payroll.status, styles['Normal'])
            ])
        
        max_rows_per_page = 20
        for i in range(0, len(table_data), max_rows_per_page):
            if i > 0:
                story.append(PageBreak())
                story.append(Paragraph("Payroll Details (continued)", heading_style))
            
            page_data = table_data[0:1] + table_data[i+1:i+max_rows_per_page+1]
            table = Table(page_data, colWidths=[1.5*inch, 1.8*inch, 1*inch, 1*inch, 1*inch, 0.8*inch])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), PRIMARY_COLOR),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('ALIGN', (2, 0), (5, -1), 'RIGHT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 8),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('GRID', (0, 0), (-1, -1), 0.5, BORDER_COLOR),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT_BG])
            ]))
            story.append(table)
    else:
        story.append(Paragraph("No payroll records found for this period.", styles['Normal']))
    
    header_footer = make_header_footer("PAYROLL SUMMARY REPORT")
    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)
    return output_path

def generate_headcount_report_pdf(dept_headcount, role_headcount, status_headcount, output_path):
    """Generate professional headcount report PDF"""
    doc = SimpleDocTemplate(output_path, pagesize=A4,
                           rightMargin=0.5*inch, leftMargin=0.5*inch,
                           topMargin=1*inch, bottomMargin=0.8*inch)
    story = []
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle('Title', parent=styles['Heading1'],
                                 fontSize=24, textColor=PRIMARY_COLOR,
                                 spaceAfter=10, alignment=TA_CENTER,
                                 fontName='Helvetica-Bold')
    
    subtitle_style = ParagraphStyle('Subtitle', parent=styles['Normal'],
                                    fontSize=11, textColor=colors.grey,
                                    alignment=TA_CENTER, spaceAfter=20)
    
    heading_style = ParagraphStyle('Heading', parent=styles['Heading2'],
                                   fontSize=14, textColor=SECONDARY_COLOR,
                                   spaceAfter=12, fontName='Helvetica-Bold')
    
    # Title
    story.append(Paragraph("HEADCOUNT REPORT", title_style))
    story.append(Paragraph(f"Generated on {datetime.now().strftime('%B %d, %Y')}", subtitle_style))
    story.append(Spacer(1, 0.3*inch))
    
    # Department Headcount
    if dept_headcount:
        story.append(Paragraph("By Department", heading_style))
        dept_data = [[
            Paragraph('Department', styles['Normal']),
            Paragraph('Employee Count', styles['Normal'])
        ]]
        for dept_name, count in dept_headcount:
            dept_data.append([
                Paragraph(dept_name or 'Unassigned', styles['Normal']),
                Paragraph(str(count), styles['Normal'])
            ])
        
        dept_table = Table(dept_data, colWidths=[4*inch, 2*inch])
        dept_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), PRIMARY_COLOR),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('ALIGN', (1, 0), (1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, BORDER_COLOR),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT_BG])
        ]))
        story.append(dept_table)
        story.append(Spacer(1, 0.4*inch))
    
    # Employment Type Headcount
    if role_headcount:
        story.append(Paragraph("By Employment Type", heading_style))
        role_data = [[
            Paragraph('Employment Type', styles['Normal']),
            Paragraph('Count', styles['Normal'])
        ]]
        for count, emp_type in role_headcount:
            role_data.append([
                Paragraph(emp_type or 'N/A', styles['Normal']),
                Paragraph(str(count), styles['Normal'])
            ])
        
        role_table = Table(role_data, colWidths=[4*inch, 2*inch])
        role_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), ACCENT_COLOR),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('ALIGN', (1, 0), (1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, BORDER_COLOR),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT_BG])
        ]))
        story.append(role_table)
        story.append(Spacer(1, 0.4*inch))
    
    # Status Headcount
    if status_headcount:
        story.append(Paragraph("By Status", heading_style))
        status_data = [[
            Paragraph('Status', styles['Normal']),
            Paragraph('Count', styles['Normal'])
        ]]
        for status, count in status_headcount:
            status_data.append([
                Paragraph(status or 'N/A', styles['Normal']),
                Paragraph(str(count), styles['Normal'])
            ])
        
        status_table = Table(status_data, colWidths=[4*inch, 2*inch])
        status_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), SUCCESS_COLOR),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('ALIGN', (1, 0), (1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, BORDER_COLOR),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT_BG])
        ]))
        story.append(status_table)
    
    header_footer = make_header_footer("HEADCOUNT REPORT")
    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)
    return output_path

def generate_department_analytics_pdf(analytics, output_path):
    """Generate professional department analytics PDF"""
    doc = SimpleDocTemplate(output_path, pagesize=A4,
                           rightMargin=0.5*inch, leftMargin=0.5*inch,
                           topMargin=1*inch, bottomMargin=0.8*inch)
    story = []
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle('Title', parent=styles['Heading1'],
                                 fontSize=24, textColor=PRIMARY_COLOR,
                                 spaceAfter=10, alignment=TA_CENTER,
                                 fontName='Helvetica-Bold')
    
    subtitle_style = ParagraphStyle('Subtitle', parent=styles['Normal'],
                                    fontSize=11, textColor=colors.grey,
                                    alignment=TA_CENTER, spaceAfter=20)
    
    heading_style = ParagraphStyle('Heading', parent=styles['Heading2'],
                                   fontSize=14, textColor=SECONDARY_COLOR,
                                   spaceAfter=12, fontName='Helvetica-Bold')
    
    # Title
    story.append(Paragraph("DEPARTMENT ANALYTICS REPORT", title_style))
    story.append(Paragraph(f"Generated on {datetime.now().strftime('%B %d, %Y')}", subtitle_style))
    story.append(Spacer(1, 0.3*inch))
    
    if analytics:
        table_data = [[
            Paragraph('Department', styles['Normal']),
            Paragraph('Employee Count', styles['Normal']),
            Paragraph('This Month Attendance', styles['Normal']),
            Paragraph('Pending Leaves', styles['Normal'])
        ]]
        
        for data in analytics:
            table_data.append([
                Paragraph(data['department'].name if data['department'] else 'N/A', styles['Normal']),
                Paragraph(str(data['employee_count']), styles['Normal']),
                Paragraph(str(data['attendance_count']), styles['Normal']),
                Paragraph(str(data['pending_leaves']), styles['Normal'])
            ])
        
        table = Table(table_data, colWidths=[2*inch, 1.5*inch, 1.8*inch, 1.5*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), PRIMARY_COLOR),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, BORDER_COLOR),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT_BG])
        ]))
        story.append(table)
    else:
        story.append(Paragraph("No department data available.", styles['Normal']))
    
    header_footer = make_header_footer("DEPARTMENT ANALYTICS REPORT")
    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)
    return output_path

