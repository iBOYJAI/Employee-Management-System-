from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime

def export_employees_to_excel(employees, output_path):
    """Export employees list to Excel"""
    wb = Workbook()
    ws = wb.active
    ws.title = "Employees"
    
    # Header row
    headers = ['Employee ID', 'First Name', 'Last Name', 'Email', 'Phone', 
               'Department', 'Role', 'Hire Date', 'Status', 'Base Salary']
    
    # Style for header
    header_fill = PatternFill(start_color='2A4365', end_color='2A4365', fill_type='solid')
    header_font = Font(bold=True, color='FFFFFF', size=12)
    border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # Write headers
    for col_num, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_num)
        cell.value = header
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = border
    
    # Write data
    for row_num, employee in enumerate(employees, 2):
        ws.cell(row=row_num, column=1, value=employee.employee_id)
        ws.cell(row=row_num, column=2, value=employee.first_name)
        ws.cell(row=row_num, column=3, value=employee.last_name)
        ws.cell(row=row_num, column=4, value=employee.email)
        ws.cell(row=row_num, column=5, value=employee.phone or '')
        ws.cell(row=row_num, column=6, value=employee.department.name if employee.department else '')
        ws.cell(row=row_num, column=7, value=employee.job_role.name if employee.job_role else '')
        ws.cell(row=row_num, column=8, value=str(employee.hire_date))
        ws.cell(row=row_num, column=9, value=employee.status)
        ws.cell(row=row_num, column=10, value=float(employee.base_salary))
        
        # Apply borders
        for col_num in range(1, len(headers) + 1):
            ws.cell(row=row_num, column=col_num).border = border
    
    # Auto-adjust column widths
    for col_num in range(1, len(headers) + 1):
        column_letter = get_column_letter(col_num)
        ws.column_dimensions[column_letter].width = 15
    
    wb.save(output_path)
    return output_path

def export_attendance_to_excel(attendance_records, output_path):
    """Export attendance records to Excel"""
    wb = Workbook()
    ws = wb.active
    ws.title = "Attendance"
    
    headers = ['Date', 'Employee ID', 'Employee Name', 'Check In', 'Check Out', 
               'Hours Worked', 'Status', 'Notes']
    
    header_fill = PatternFill(start_color='2A4365', end_color='2A4365', fill_type='solid')
    header_font = Font(bold=True, color='FFFFFF', size=12)
    border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    for col_num, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_num)
        cell.value = header
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = border
    
    for row_num, record in enumerate(attendance_records, 2):
        ws.cell(row=row_num, column=1, value=str(record.date))
        ws.cell(row=row_num, column=2, value=record.employee.employee_id)
        ws.cell(row=row_num, column=3, value=record.employee.full_name)
        ws.cell(row=row_num, column=4, value=str(record.check_in) if record.check_in else '')
        ws.cell(row=row_num, column=5, value=str(record.check_out) if record.check_out else '')
        ws.cell(row=row_num, column=6, value=float(record.hours_worked) if record.hours_worked else 0)
        ws.cell(row=row_num, column=7, value=record.status)
        ws.cell(row=row_num, column=8, value=record.notes or '')
        
        for col_num in range(1, len(headers) + 1):
            ws.cell(row=row_num, column=col_num).border = border
    
    for col_num in range(1, len(headers) + 1):
        column_letter = get_column_letter(col_num)
        ws.column_dimensions[column_letter].width = 15
    
    wb.save(output_path)
    return output_path

