from functools import wraps
from flask import abort, current_app
from flask_login import current_user
from datetime import datetime, date, timedelta
import os
from werkzeug.utils import secure_filename
import calendar

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'Admin':
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

def hr_or_admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role not in ['Admin', 'HR']:
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

def manager_or_above_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role not in ['Admin', 'HR', 'Manager']:
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']

def save_uploaded_file(file, folder='documents'):
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{timestamp}_{filename}"
        upload_folder = current_app.config['UPLOAD_FOLDER']
        # Convert Path object to string if needed
        if hasattr(upload_folder, '__fspath__'):
            upload_folder = str(upload_folder)
        upload_path = os.path.join(upload_folder, folder)
        os.makedirs(upload_path, exist_ok=True)
        filepath = os.path.join(upload_path, filename)
        file.save(filepath)
        return os.path.join(folder, filename).replace('\\', '/')  # Use forward slashes for web paths
    return None

def generate_employee_id(department_id=None):
    """Generate unique employee ID"""
    from app import db
    from app.models import Employee
    
    year = datetime.now().year
    prefix = f"EMP{year}"
    
    # Get last employee ID for this year
    last_employee = Employee.query.filter(
        Employee.employee_id.like(f"{prefix}%")
    ).order_by(Employee.id.desc()).first()
    
    if last_employee:
        try:
            last_num = int(last_employee.employee_id[-4:])
            new_num = last_num + 1
        except:
            new_num = 1
    else:
        new_num = 1
    
    return f"{prefix}{new_num:04d}"

def calculate_working_days(start_date, end_date):
    """Calculate working days between two dates (excluding weekends)"""
    if isinstance(start_date, str):
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
    if isinstance(end_date, str):
        end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
    
    days = 0
    current = start_date
    while current <= end_date:
        if current.weekday() < 5:  # Monday = 0, Friday = 4
            days += 1
        current += timedelta(days=1)
    return days

def calculate_hours_worked(check_in, check_out):
    """Calculate hours worked from check-in and check-out times"""
    if not check_in or not check_out:
        return 0
    
    if isinstance(check_in, str):
        check_in = datetime.strptime(check_in, '%H:%M:%S').time()
    if isinstance(check_out, str):
        check_out = datetime.strptime(check_out, '%H:%M:%S').time()
    
    check_in_dt = datetime.combine(date.today(), check_in)
    check_out_dt = datetime.combine(date.today(), check_out)
    
    if check_out_dt < check_in_dt:
        check_out_dt += timedelta(days=1)
    
    diff = check_out_dt - check_in_dt
    return round(diff.total_seconds() / 3600, 2)

def get_month_range(year, month):
    """Get start and end date of a month"""
    start_date = date(year, month, 1)
    last_day = calendar.monthrange(year, month)[1]
    end_date = date(year, month, last_day)
    return start_date, end_date

def format_currency(amount, currency='INR'):
    """Format amount as currency with INR default"""
    try:
        amount = float(amount)
    except Exception:
        return amount
    if currency == 'INR':
        return f"₹{amount:,.2f}"
    return f"{amount:,.2f} {currency}"

def log_activity(user_id, action, entity_type=None, entity_id=None, details=None, ip_address=None):
    """Log user activity"""
    from app import db
    from app.models import ActivityLog
    
    log = ActivityLog(
        user_id=user_id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        details=details,
        ip_address=ip_address
    )
    db.session.add(log)
    db.session.commit()

def create_notification(user_id, title, message, type='info', link=None):
    """Create a notification for a user"""
    from app import db
    from app.models import Notification
    
    notification = Notification(
        user_id=user_id,
        title=title,
        message=message,
        type=type,
        link=link
    )
    db.session.add(notification)
    db.session.commit()
    return notification

