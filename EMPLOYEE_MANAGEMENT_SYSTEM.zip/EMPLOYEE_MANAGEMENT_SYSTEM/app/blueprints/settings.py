from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app import db
from app.models import Setting, Department, Role, User, Employee, ActivityLog
from app.utils.helpers import admin_required, hr_or_admin_required, log_activity
from datetime import datetime

bp = Blueprint('settings', __name__)

@bp.route('/')
@login_required
def index():
    return render_template('settings/index.html')

@bp.route('/company', methods=['GET', 'POST'])
@admin_required
@login_required
def company():
    if request.method == 'POST':
        settings_to_update = [
            'company_name', 'company_address', 'company_phone',
            'company_email', 'fiscal_year_start', 'working_hours_per_day', 'tax_rate'
        ]
        
        for key in settings_to_update:
            value = request.form.get(key)
            setting = Setting.query.filter_by(key=key).first()
            
            if setting:
                setting.value = value
            else:
                setting = Setting(key=key, value=value)
                db.session.add(setting)
        
        db.session.commit()
        flash('Company settings updated successfully!', 'success')
        return redirect(url_for('settings.company'))
    
    settings = {s.key: s.value for s in Setting.query.all()}
    return render_template('settings/company.html', settings=settings)

@bp.route('/departments', methods=['GET', 'POST'])
@hr_or_admin_required
@login_required
def departments():
    if request.method == 'POST':
        try:
            department = Department(
                name=request.form.get('name'),
                description=request.form.get('description'),
                manager_id=request.form.get('manager_id') or None,
                budget=float(request.form.get('budget', 0)) if request.form.get('budget') else None
            )
            
            db.session.add(department)
            db.session.commit()
            
            flash('Department added successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding department: {str(e)}', 'error')
    
    departments = Department.query.all()
    managers = Employee.query.filter_by(status='Active').all()
    
    return render_template('settings/departments.html',
                         departments=departments,
                         managers=managers)

@bp.route('/departments/<int:id>/edit', methods=['POST'])
@hr_or_admin_required
@login_required
def edit_department(id):
    department = Department.query.get_or_404(id)
    
    try:
        department.name = request.form.get('name')
        department.description = request.form.get('description')
        department.manager_id = request.form.get('manager_id') or None
        department.budget = float(request.form.get('budget', 0)) if request.form.get('budget') else None
        
        db.session.commit()
        flash('Department updated successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating department: {str(e)}', 'error')
    
    return redirect(url_for('settings.departments'))

@bp.route('/roles', methods=['GET', 'POST'])
@hr_or_admin_required
@login_required
def roles():
    if request.method == 'POST':
        try:
            role = Role(
                name=request.form.get('name'),
                description=request.form.get('description')
            )
            
            db.session.add(role)
            db.session.commit()
            
            flash('Role added successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding role: {str(e)}', 'error')
    
    roles = Role.query.all()
    return render_template('settings/roles.html', roles=roles)

@bp.route('/roles/<int:id>/edit', methods=['POST'])
@hr_or_admin_required
@login_required
def edit_role(id):
    role = Role.query.get_or_404(id)
    
    try:
        role.name = request.form.get('name')
        role.description = request.form.get('description')
        
        db.session.commit()
        flash('Role updated successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating role: {str(e)}', 'error')
    
    return redirect(url_for('settings.roles'))

@bp.route('/activity-log')
@admin_required
@login_required
def activity_log():
    page = request.args.get('page', 1, type=int)
    user_id = request.args.get('user_id', 0, type=int)
    start_date = request.args.get('start_date', '')
    end_date = request.args.get('end_date', '')

    query = ActivityLog.query
    if user_id:
        query = query.filter_by(user_id=user_id)
    if start_date:
        query = query.filter(ActivityLog.created_at >= start_date + " 00:00:00")
    if end_date:
        query = query.filter(ActivityLog.created_at <= end_date + " 23:59:59")

    pagination = query.order_by(ActivityLog.created_at.desc())\
        .paginate(page=page, per_page=50, error_out=False)
    
    logs = pagination.items
    users = User.query.order_by(User.username.asc()).all()
    
    return render_template('settings/activity_log.html',
                         logs=logs,
                         pagination=pagination,
                         users=users,
                         user_id=user_id,
                         start_date=start_date,
                         end_date=end_date)

@bp.route('/users')
@admin_required
@login_required
def users():
    page = request.args.get('page', 1, type=int)
    
    pagination = User.query.order_by(User.created_at.desc())\
        .paginate(page=page, per_page=20, error_out=False)
    
    users = pagination.items
    
    return render_template('settings/users.html',
                         users=users,
                         pagination=pagination)

