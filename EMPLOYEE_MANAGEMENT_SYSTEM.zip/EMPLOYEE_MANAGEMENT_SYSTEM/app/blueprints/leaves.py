from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from app import db
from app.models import Leave, LeaveType, Employee
from app.utils.helpers import manager_or_above_required, calculate_working_days, log_activity, create_notification
from datetime import datetime, date, timedelta

bp = Blueprint('leaves', __name__)

@bp.route('/')
@login_required
def index():
    page = request.args.get('page', 1, type=int)
    status_filter = request.args.get('status', '', type=str)
    
    query = Leave.query
    
    # Role-based filtering
    if current_user.role == 'Employee' and current_user.employee:
        query = query.filter_by(employee_id=current_user.employee.id)
    elif current_user.role == 'Manager' and current_user.employee:
        # Managers see their team's leaves
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        query = query.filter(Leave.employee_id.in_(team_ids))
    
    if status_filter:
        query = query.filter_by(status=status_filter)
    
    pagination = query.order_by(Leave.applied_at.desc()).paginate(
        page=page, per_page=15, error_out=False
    )
    leaves = pagination.items
    
    return render_template('leaves/index.html',
                         leaves=leaves,
                         pagination=pagination,
                         status_filter=status_filter)

@bp.route('/<int:id>/json')
@login_required
def leave_json(id):
    leave = Leave.query.get_or_404(id)
    # permission check
    if current_user.role == 'Employee' and leave.employee_id != current_user.employee_id:
        return jsonify({'success': False, 'message': 'Forbidden'}), 403
    if current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        if leave.employee_id not in team_ids:
            return jsonify({'success': False, 'message': 'Forbidden'}), 403
    return jsonify({
        'success': True,
        'id': leave.id,
        'employee': leave.employee.full_name,
        'leave_type': leave.leave_type.name,
        'start_date': leave.start_date.isoformat(),
        'end_date': leave.end_date.isoformat(),
        'days': leave.days,
        'status': leave.status,
        'reason': leave.reason,
        'applied_at': leave.applied_at.isoformat() if leave.applied_at else None,
        'approved_by': leave.approver.full_name if leave.approver else None,
        'rejection_reason': leave.rejection_reason
    })

@bp.route('/apply', methods=['GET', 'POST'])
@login_required
def apply():
    if not current_user.employee:
        flash('No employee record found.', 'error')
        return redirect(url_for('dashboard.index'))
    
    if request.method == 'POST':
        try:
            leave_type_id = request.form.get('leave_type_id')
            start_date = datetime.strptime(request.form.get('start_date'), '%Y-%m-%d').date()
            end_date = datetime.strptime(request.form.get('end_date'), '%Y-%m-%d').date()
            reason = request.form.get('reason')
            
            if end_date < start_date:
                flash('End date must be after start date.', 'error')
                return redirect(url_for('leaves.apply'))
            
            days = calculate_working_days(start_date, end_date)
            
            # Check leave balance (simplified - can be enhanced)
            leave_type = LeaveType.query.get(leave_type_id)
            if leave_type and leave_type.max_days > 0:
                used_leaves = db.session.query(db.func.sum(Leave.days)).filter_by(
                    employee_id=current_user.employee.id,
                    leave_type_id=leave_type_id,
                    status='Approved'
                ).scalar() or 0
                
                if used_leaves + days > leave_type.max_days:
                    flash(f'Insufficient leave balance. Available: {leave_type.max_days - used_leaves} days', 'error')
                    return redirect(url_for('leaves.apply'))
            
            leave = Leave(
                employee_id=current_user.employee.id,
                leave_type_id=leave_type_id,
                start_date=start_date,
                end_date=end_date,
                days=days,
                reason=reason,
                status='Pending'
            )
            
            db.session.add(leave)
            db.session.commit()
            
            # Notify manager (handle one-to-one or list backref)
            if current_user.employee.manager:
                mgr_user_rel = current_user.employee.manager.user_account
                mgr_user = mgr_user_rel[0] if hasattr(mgr_user_rel, '__iter__') and not isinstance(mgr_user_rel, dict) else mgr_user_rel
                if mgr_user:
                    create_notification(
                        user_id=mgr_user.id,
                        title='New Leave Application',
                        message=f"{current_user.employee.full_name} has applied for {days} days leave",
                        type='info',
                        link=url_for('leaves.approvals')
                    )
            
            log_activity(
                user_id=current_user.id,
                action='Leave Applied',
                entity_type='Leave',
                entity_id=leave.id
            )
            
            flash('Leave application submitted successfully!', 'success')
            return redirect(url_for('leaves.index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error applying leave: {str(e)}', 'error')
    
    leave_types = LeaveType.query.all()
    return render_template('leaves/apply.html', leave_types=leave_types)

@bp.route('/approvals')
@manager_or_above_required
@login_required
def approvals():
    page = request.args.get('page', 1, type=int)
    
    # Get pending leaves for manager's team
    if current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        query = Leave.query.filter(
            Leave.employee_id.in_(team_ids),
            Leave.status == 'Pending'
        )
    else:
        query = Leave.query.filter_by(status='Pending')
    
    pagination = query.order_by(Leave.applied_at.asc()).paginate(
        page=page, per_page=15, error_out=False
    )
    leaves = pagination.items
    
    return render_template('leaves/approvals.html',
                         leaves=leaves,
                         pagination=pagination)

@bp.route('/<int:id>/approve', methods=['POST'])
@manager_or_above_required
@login_required
def approve(id):
    leave = Leave.query.get_or_404(id)
    
    # Check permission
    if current_user.role == 'Manager':
        if leave.employee.manager_id != current_user.employee.id:
            flash('You do not have permission to approve this leave.', 'error')
            return redirect(url_for('leaves.approvals'))
    
    leave.status = 'Approved'
    leave.approved_by = current_user.employee.id
    leave.approved_at = datetime.utcnow()
    
    db.session.commit()
    
    # Notify employee
    if leave.employee.user_account:
        create_notification(
            user_id=leave.employee.user_account.id,
            title='Leave Approved',
            message=f'Your leave application from {leave.start_date} to {leave.end_date} has been approved.',
            type='success',
            link=url_for('leaves.index')
        )
    
    log_activity(
        user_id=current_user.id,
        action='Leave Approved',
        entity_type='Leave',
        entity_id=leave.id
    )
    
    flash('Leave approved successfully!', 'success')
    return redirect(url_for('leaves.approvals'))

@bp.route('/<int:id>/reject', methods=['POST'])
@manager_or_above_required
@login_required
def reject(id):
    leave = Leave.query.get_or_404(id)
    rejection_reason = request.form.get('rejection_reason', '')
    
    # Check permission
    if current_user.role == 'Manager':
        if leave.employee.manager_id != current_user.employee.id:
            flash('You do not have permission to reject this leave.', 'error')
            return redirect(url_for('leaves.approvals'))
    
    leave.status = 'Rejected'
    leave.approved_by = current_user.employee.id
    leave.approved_at = datetime.utcnow()
    leave.rejection_reason = rejection_reason
    
    db.session.commit()
    
    # Notify employee
    if leave.employee.user_account:
        create_notification(
            user_id=leave.employee.user_account.id,
            title='Leave Rejected',
            message=f'Your leave application has been rejected. Reason: {rejection_reason}',
            type='error',
            link=url_for('leaves.index')
        )
    
    log_activity(
        user_id=current_user.id,
        action='Leave Rejected',
        entity_type='Leave',
        entity_id=leave.id
    )
    
    flash('Leave rejected.', 'info')
    return redirect(url_for('leaves.approvals'))

@bp.route('/calendar')
@login_required
def calendar():
    year = request.args.get('year', date.today().year, type=int)
    month = request.args.get('month', date.today().month, type=int)
    
    start_date = date(year, month, 1)
    last_day = (date(year, month + 1, 1) - timedelta(days=1)).day if month < 12 else 31
    end_date = date(year, month, last_day)
    
    query = Leave.query.filter(
        Leave.start_date <= end_date,
        Leave.end_date >= start_date
    )
    
    if current_user.role == 'Employee' and current_user.employee:
        query = query.filter_by(employee_id=current_user.employee.id)
    elif current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        query = query.filter(Leave.employee_id.in_(team_ids))
    
    leaves = query.all()
    
    return render_template('leaves/calendar.html',
                         year=year,
                         month=month,
                         leaves=leaves)

