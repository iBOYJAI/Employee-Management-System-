from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file, jsonify
from flask_login import login_required, current_user
from app import db
from app.models import Payroll, PayrollItem, Employee
from app.utils.helpers import hr_or_admin_required, log_activity, create_notification
from app.utils.pdf_generator import generate_payslip_pdf
from datetime import datetime, date
from calendar import monthrange
import os

bp = Blueprint('payroll', __name__)

@bp.route('/')
@login_required
def index():
    page = request.args.get('page', 1, type=int)
    month = request.args.get('month', date.today().month, type=int)
    year = request.args.get('year', date.today().year, type=int)
    employee_id = request.args.get('employee_id', 0, type=int)
    status = request.args.get('status', '', type=str)
    
    query = Payroll.query
    
    # Role-based filtering
    if current_user.role == 'Employee' and current_user.employee:
        query = query.filter_by(employee_id=current_user.employee.id)
    elif current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        query = query.filter(Payroll.employee_id.in_(team_ids))
    
    # Filter by employee (for admins/managers) or enforce self/team
    if employee_id:
        query = query.filter_by(employee_id=employee_id)
    if status:
        query = query.filter_by(status=status)

    # Filter by month/year
    start_date = date(year, month, 1)
    last_day = monthrange(year, month)[1]
    end_date = date(year, month, last_day)
    
    query = query.filter(
        Payroll.pay_period_start >= start_date,
        Payroll.pay_period_end <= end_date
    )
    
    pagination = query.order_by(Payroll.pay_date.desc()).paginate(
        page=page, per_page=15, error_out=False
    )
    payrolls = pagination.items
    
    employees = Employee.query.filter_by(status='Active').all()
    
    return render_template('payroll/index.html',
                         payrolls=payrolls,
                         pagination=pagination,
                         month=month,
                         year=year,
                         employee_id=employee_id,
                         status=status,
                         employees=employees)

@bp.route('/run', methods=['GET', 'POST'])
@hr_or_admin_required
@login_required
def run():
    if request.method == 'POST':
        try:
            month = int(request.form.get('month'))
            year = int(request.form.get('year'))
            employee_ids = request.form.getlist('employee_ids')
            
            start_date = date(year, month, 1)
            last_day = monthrange(year, month)[1]
            end_date = date(year, month, last_day)
            pay_date = date.today()
            
            if not employee_ids:
                employees = Employee.query.filter_by(status='Active').all()
            else:
                employees = Employee.query.filter(Employee.id.in_(employee_ids)).all()
            
            processed = 0
            for employee in employees:
                # Check if payroll already exists
                existing = Payroll.query.filter_by(
                    employee_id=employee.id,
                    pay_period_start=start_date,
                    pay_period_end=end_date
                ).first()
                
                if existing:
                    continue
                
                # Calculate payroll
                base_salary = float(employee.base_salary)
                
                # Calculate earnings (simplified - can add bonuses, allowances, etc.)
                earnings = [
                    {'name': 'Base Salary', 'amount': base_salary}
                ]
                
                # Calculate deductions (simplified - can add tax, insurance, etc.)
                tax_rate = 0.15  # 15% tax
                tax_amount = base_salary * tax_rate
                
                deductions = [
                    {'name': 'Income Tax', 'amount': tax_amount}
                ]
                
                gross_salary = sum(e['amount'] for e in earnings)
                total_deductions = sum(d['amount'] for d in deductions)
                net_salary = gross_salary - total_deductions
                
                # Create payroll record
                payroll = Payroll(
                    employee_id=employee.id,
                    pay_period_start=start_date,
                    pay_period_end=end_date,
                    pay_date=pay_date,
                    base_salary=base_salary,
                    gross_salary=gross_salary,
                    total_deductions=total_deductions,
                    net_salary=net_salary,
                    status='Processed'
                )
                
                db.session.add(payroll)
                db.session.flush()
                
                # Add payroll items
                for earning in earnings:
                    item = PayrollItem(
                        payroll_id=payroll.id,
                        item_type='Earning',
                        name=earning['name'],
                        amount=earning['amount']
                    )
                    db.session.add(item)
                
                for deduction in deductions:
                    item = PayrollItem(
                        payroll_id=payroll.id,
                        item_type='Deduction',
                        name=deduction['name'],
                        amount=deduction['amount']
                    )
                    db.session.add(item)
                
                # Notify employee (handle one-to-one or list backref)
                if employee.user_account:
                    target_user = employee.user_account[0] if hasattr(employee.user_account, '__iter__') and not isinstance(employee.user_account, dict) else employee.user_account
                    if target_user:
                        create_notification(
                            user_id=target_user.id,
                            title='Payroll Processed',
                            message=f'Your payroll for {start_date.strftime("%B %Y")} has been processed.',
                            type='success',
                            link=url_for('payroll.index')
                        )
                
                processed += 1
            
            db.session.commit()
            
            log_activity(
                user_id=current_user.id,
                action='Payroll Run',
                details=f'Processed payroll for {processed} employees'
            )
            
            flash(f'Payroll processed successfully for {processed} employees!', 'success')
            return redirect(url_for('payroll.index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error processing payroll: {str(e)}', 'error')
    
    employees = Employee.query.filter_by(status='Active').all()
    return render_template('payroll/run.html', employees=employees)

@bp.route('/<int:id>')
@login_required
def view(id):
    payroll = Payroll.query.get_or_404(id)
    
    # Check access
    if current_user.role == 'Employee' and payroll.employee_id != current_user.employee_id:
        flash('You do not have permission to view this payroll.', 'error')
        return redirect(url_for('payroll.index'))
    
    earnings = PayrollItem.query.filter_by(
        payroll_id=id,
        item_type='Earning'
    ).all()
    
    deductions = PayrollItem.query.filter_by(
        payroll_id=id,
        item_type='Deduction'
    ).all()
    
    return render_template('payroll/view.html',
                         payroll=payroll,
                         earnings=earnings,
                         deductions=deductions)

@bp.route('/<int:id>/payslip')
@login_required
def payslip(id):
    payroll = Payroll.query.get_or_404(id)
    
    # Check access
    if current_user.role == 'Employee' and payroll.employee_id != current_user.employee_id:
        flash('You do not have permission to view this payslip.', 'error')
        return redirect(url_for('payroll.index'))
    
    earnings = PayrollItem.query.filter_by(
        payroll_id=id,
        item_type='Earning'
    ).all()
    
    deductions = PayrollItem.query.filter_by(
        payroll_id=id,
        item_type='Deduction'
    ).all()
    
    payroll_data = {
        'pay_period_start': payroll.pay_period_start,
        'pay_period_end': payroll.pay_period_end,
        'pay_date': payroll.pay_date,
        'gross_salary': float(payroll.gross_salary),
        'net_salary': float(payroll.net_salary),
        'earnings': [{'name': e.name, 'amount': float(e.amount)} for e in earnings],
        'deductions': [{'name': d.name, 'amount': float(d.amount)} for d in deductions]
    }
    
    employee_data = {
        'full_name': payroll.employee.full_name,
        'employee_id': payroll.employee.employee_id,
        'department': payroll.employee.department.name if payroll.employee.department else 'N/A'
    }
    
    uploads_dir = os.path.join(os.getcwd(), 'uploads')
    os.makedirs(uploads_dir, exist_ok=True)
    output_path = os.path.join(uploads_dir, f'payslip_{payroll.id}.pdf')
    generate_payslip_pdf(payroll_data, employee_data, output_path)
    
    return send_file(output_path, as_attachment=True, download_name=f'payslip_{payroll.employee.employee_id}.pdf')

