from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app import db
from app.models import Asset, AssetAssignment, Employee
from app.utils.helpers import hr_or_admin_required, log_activity
from datetime import datetime, date

bp = Blueprint('assets', __name__)

@bp.route('/')
@login_required
def index():
    page = request.args.get('page', 1, type=int)
    status_filter = request.args.get('status', '', type=str)
    
    query = Asset.query
    
    if status_filter:
        query = query.filter_by(status=status_filter)
    
    pagination = query.order_by(Asset.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    assets = pagination.items
    
    return render_template('assets/index.html',
                         assets=assets,
                         pagination=pagination,
                         status_filter=status_filter)

@bp.route('/add', methods=['GET', 'POST'])
@hr_or_admin_required
@login_required
def add():
    if request.method == 'POST':
        try:
            # Generate asset code
            category = request.form.get('category')
            asset_code = f"{category[:3].upper()}{datetime.now().strftime('%Y%m%d%H%M%S')}"
            
            asset = Asset(
                asset_code=asset_code,
                name=request.form.get('name'),
                category=request.form.get('category'),
                brand=request.form.get('brand'),
                model=request.form.get('model'),
                serial_number=request.form.get('serial_number'),
                purchase_date=datetime.strptime(request.form.get('purchase_date'), '%Y-%m-%d').date() if request.form.get('purchase_date') else None,
                purchase_cost=float(request.form.get('purchase_cost', 0)) if request.form.get('purchase_cost') else None,
                status='Available',
                notes=request.form.get('notes')
            )
            
            db.session.add(asset)
            db.session.commit()
            
            log_activity(
                user_id=current_user.id,
                action='Asset Added',
                entity_type='Asset',
                entity_id=asset.id
            )
            
            flash('Asset added successfully!', 'success')
            return redirect(url_for('assets.index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding asset: {str(e)}', 'error')
    
    return render_template('assets/add.html')

@bp.route('/<int:id>/assign', methods=['GET', 'POST'])
@hr_or_admin_required
@login_required
def assign(id):
    asset = Asset.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            employee_id = request.form.get('employee_id')
            assigned_date = datetime.strptime(request.form.get('assigned_date'), '%Y-%m-%d').date()
            notes = request.form.get('notes')
            
            # Create assignment
            assignment = AssetAssignment(
                asset_id=id,
                employee_id=employee_id,
                assigned_date=assigned_date,
                assigned_by=current_user.employee.id if current_user.employee else None,
                notes=notes
            )
            
            # Update asset status
            asset.status = 'Assigned'
            
            db.session.add(assignment)
            db.session.commit()
            
            log_activity(
                user_id=current_user.id,
                action='Asset Assigned',
                entity_type='AssetAssignment',
                entity_id=assignment.id
            )
            
            flash('Asset assigned successfully!', 'success')
            return redirect(url_for('assets.index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error assigning asset: {str(e)}', 'error')
    
    employees = Employee.query.filter_by(status='Active').all()
    return render_template('assets/assign.html', asset=asset, employees=employees)

@bp.route('/assignment/<int:id>/return', methods=['POST'])
@hr_or_admin_required
@login_required
def return_asset(id):
    assignment = AssetAssignment.query.get_or_404(id)
    
    try:
        assignment.return_date = date.today()
        assignment.asset.status = 'Available'
        
        db.session.commit()
        
        log_activity(
            user_id=current_user.id,
            action='Asset Returned',
            entity_type='AssetAssignment',
            entity_id=assignment.id
        )
        
        flash('Asset returned successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error returning asset: {str(e)}', 'error')
    
    return redirect(url_for('assets.index'))

@bp.route('/my-assets')
@login_required
def my_assets():
    if not current_user.employee:
        flash('No employee record found.', 'error')
        return redirect(url_for('dashboard.index'))
    
    assignments = AssetAssignment.query.filter_by(
        employee_id=current_user.employee.id,
        return_date=None
    ).all()
    
    return render_template('assets/my_assets.html', assignments=assignments)

