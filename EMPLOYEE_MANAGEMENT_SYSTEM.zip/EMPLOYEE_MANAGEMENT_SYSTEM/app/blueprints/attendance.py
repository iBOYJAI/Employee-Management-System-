from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_login import login_required, current_user
from app import db
from app.models import Attendance, Employee
from app.utils.helpers import hr_or_admin_required, calculate_hours_worked, log_activity, generate_employee_id
from app.utils.excel_export import export_attendance_to_excel
from datetime import datetime, date, timedelta
from calendar import monthrange
import os

bp = Blueprint('attendance', __name__)


def ensure_employee_profile():
    """Ensure current_user has an employee profile; create a minimal one if missing."""
    if not current_user.is_authenticated:
        return None
    if current_user.employee:
        return current_user.employee

    # Create minimal employee linked to this user
    emp = Employee(
        employee_id=generate_employee_id(),
        first_name=current_user.username,
        last_name='User',
        email=current_user.email or f'{current_user.username}@example.com',
        hire_date=date.today(),
        employment_type='Full-time',
        status='Active',
        base_salary=0,
        currency='INR'
    )
    db.session.add(emp)
    db.session.flush()
    current_user.employee_id = emp.id
    db.session.commit()
    return emp

@bp.route('/')
@login_required
def index():
    page = request.args.get('page', 1, type=int)
    employee_id = request.args.get('employee_id', 0, type=int)
    start_date = request.args.get('start_date', '')
    end_date = request.args.get('end_date', '')
    
    query = Attendance.query
    
    # Role-based filtering
    if current_user.role == 'Employee' and current_user.employee:
        query = query.filter_by(employee_id=current_user.employee.id)
    elif current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        query = query.filter(Attendance.employee_id.in_(team_ids))
    
    if employee_id:
        query = query.filter_by(employee_id=employee_id)
    
    if start_date:
        query = query.filter(Attendance.date >= datetime.strptime(start_date, '%Y-%m-%d').date())
    if end_date:
        query = query.filter(Attendance.date <= datetime.strptime(end_date, '%Y-%m-%d').date())
    
    pagination = query.order_by(Attendance.date.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    records = pagination.items
    
    employees = Employee.query.filter_by(status='Active').all()
    
    return render_template('attendance/index.html',
                         records=records,
                         pagination=pagination,
                         employees=employees,
                         employee_id=employee_id,
                         start_date=start_date,
                         end_date=end_date)

@bp.route('/calendar')
@login_required
def calendar_view():
    year = request.args.get('year', date.today().year, type=int)
    month = request.args.get('month', date.today().month, type=int)
    employee_id = request.args.get('employee_id', 0, type=int)
    
    # Get all attendance for the month
    start_date = date(year, month, 1)
    last_day = monthrange(year, month)[1]
    end_date = date(year, month, last_day)
    
    query = Attendance.query.filter(
        Attendance.date >= start_date,
        Attendance.date <= end_date
    )
    
    if employee_id:
        query = query.filter_by(employee_id=employee_id)
    elif current_user.role == 'Employee' and current_user.employee:
        query = query.filter_by(employee_id=current_user.employee.id)
    elif current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        query = query.filter(Attendance.employee_id.in_(team_ids))
    
    attendance_records = query.all()
    
    # Create calendar data
    calendar_data = {}
    for record in attendance_records:
        day = record.date.day
        if day not in calendar_data:
            calendar_data[day] = []
        calendar_data[day].append({
            'employee': record.employee.full_name,
            'check_in': str(record.check_in) if record.check_in else None,
            'check_out': str(record.check_out) if record.check_out else None,
            'status': record.status
        })
    
    employees = Employee.query.filter_by(status='Active').all()
    
    return render_template('attendance/calendar.html',
                         year=year,
                         month=month,
                         calendar_data=calendar_data,
                         employees=employees,
                         employee_id=employee_id,
                         last_day=last_day)

@bp.route('/check-in', methods=['POST'])
@login_required
def check_in():
    emp = ensure_employee_profile()
    if not emp:
        return jsonify({'success': False, 'message': 'No employee record found'}), 400
    
    today = date.today()
    existing = Attendance.query.filter_by(
        employee_id=emp.id,
        date=today
    ).first()
    
    if existing:
        return jsonify({'success': False, 'message': 'Already checked in today'}), 400
    
    check_in_time = datetime.now().time()
    attendance = Attendance(
        employee_id=emp.id,
        date=today,
        check_in=check_in_time,
        status='Present'
    )
    
    db.session.add(attendance)
    db.session.commit()
    
    log_activity(
        user_id=current_user.id,
        action='Check In',
        entity_type='Attendance',
        entity_id=attendance.id
    )
    
    return jsonify({'success': True, 'message': 'Checked in successfully'})

@bp.route('/check-out', methods=['POST'])
@login_required
def check_out():
    emp = ensure_employee_profile()
    if not emp:
        return jsonify({'success': False, 'message': 'No employee record found'}), 400
    
    today = date.today()
    attendance = Attendance.query.filter_by(
        employee_id=emp.id,
        date=today
    ).first()
    
    if not attendance:
        return jsonify({'success': False, 'message': 'Please check in first'}), 400
    
    if attendance.check_out:
        return jsonify({'success': False, 'message': 'Already checked out today'}), 400
    
    check_out_time = datetime.now().time()
    attendance.check_out = check_out_time
    
    # Calculate hours worked
    hours = calculate_hours_worked(attendance.check_in, check_out_time)
    attendance.hours_worked = hours
    
    db.session.commit()
    
    log_activity(
        user_id=current_user.id,
        action='Check Out',
        entity_type='Attendance',
        entity_id=attendance.id
    )
    
    return jsonify({'success': True, 'message': 'Checked out successfully', 'hours': hours})

@bp.route('/add', methods=['GET', 'POST'])
@hr_or_admin_required
@login_required
def add():
    if request.method == 'POST':
        try:
            employee_id = request.form.get('employee_id')
            att_date = datetime.strptime(request.form.get('date'), '%Y-%m-%d').date()
            check_in = datetime.strptime(request.form.get('check_in'), '%H:%M').time() if request.form.get('check_in') else None
            check_out = datetime.strptime(request.form.get('check_out'), '%H:%M').time() if request.form.get('check_out') else None
            status = request.form.get('status', 'Present')
            notes = request.form.get('notes')
            
            # Check if record exists
            existing = Attendance.query.filter_by(
                employee_id=employee_id,
                date=att_date
            ).first()
            
            if existing:
                flash('Attendance record already exists for this date.', 'error')
                return redirect(url_for('attendance.add'))
            
            hours = None
            if check_in and check_out:
                hours = calculate_hours_worked(check_in, check_out)
            
            attendance = Attendance(
                employee_id=employee_id,
                date=att_date,
                check_in=check_in,
                check_out=check_out,
                hours_worked=hours,
                status=status,
                notes=notes
            )
            
            db.session.add(attendance)
            db.session.commit()
            
            log_activity(
                user_id=current_user.id,
                action='Attendance Added',
                entity_type='Attendance',
                entity_id=attendance.id
            )
            
            flash('Attendance record added successfully!', 'success')
            return redirect(url_for('attendance.index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding attendance: {str(e)}', 'error')
    
    employees = Employee.query.filter_by(status='Active').all()
    return render_template('attendance/add.html', employees=employees)

@bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@hr_or_admin_required
@login_required
def edit(id):
    attendance = Attendance.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            attendance.date = datetime.strptime(request.form.get('date'), '%Y-%m-%d').date()
            attendance.check_in = datetime.strptime(request.form.get('check_in'), '%H:%M').time() if request.form.get('check_in') else None
            attendance.check_out = datetime.strptime(request.form.get('check_out'), '%H:%M').time() if request.form.get('check_out') else None
            attendance.status = request.form.get('status')
            attendance.notes = request.form.get('notes')
            
            if attendance.check_in and attendance.check_out:
                attendance.hours_worked = calculate_hours_worked(attendance.check_in, attendance.check_out)
            
            db.session.commit()
            
            log_activity(
                user_id=current_user.id,
                action='Attendance Updated',
                entity_type='Attendance',
                entity_id=attendance.id
            )
            
            flash('Attendance record updated successfully!', 'success')
            return redirect(url_for('attendance.index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating attendance: {str(e)}', 'error')
    
    employees = Employee.query.filter_by(status='Active').all()
    return render_template('attendance/edit.html', attendance=attendance, employees=employees)

@bp.route('/export')
@hr_or_admin_required
@login_required
def export():
    start_date = request.args.get('start_date', '')
    end_date = request.args.get('end_date', '')
    
    query = Attendance.query
    
    if start_date:
        query = query.filter(Attendance.date >= datetime.strptime(start_date, '%Y-%m-%d').date())
    if end_date:
        query = query.filter(Attendance.date <= datetime.strptime(end_date, '%Y-%m-%d').date())
    
    records = query.all()
    uploads_dir = os.path.join(os.getcwd(), 'uploads')
    os.makedirs(uploads_dir, exist_ok=True)
    output_path = os.path.join(uploads_dir, 'attendance_export.xlsx')
    export_attendance_to_excel(records, output_path)
    return send_file(output_path, as_attachment=True, download_name='attendance.xlsx')

