from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app import db
from app.models import PerformanceReview, Goal, Employee
from app.utils.helpers import manager_or_above_required, log_activity
from datetime import datetime, date

bp = Blueprint('performance', __name__)

@bp.route('/')
@login_required
def index():
    page = request.args.get('page', 1, type=int)
    
    query = PerformanceReview.query
    
    # Role-based filtering
    if current_user.role == 'Employee' and current_user.employee:
        query = query.filter_by(employee_id=current_user.employee.id)
    elif current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        query = query.filter(PerformanceReview.employee_id.in_(team_ids))
    
    pagination = query.order_by(PerformanceReview.created_at.desc()).paginate(
        page=page, per_page=15, error_out=False
    )
    reviews = pagination.items
    
    return render_template('performance/index.html',
                         reviews=reviews,
                         pagination=pagination)

@bp.route('/detail/<int:review_id>')
@login_required
def detail(review_id):
    review = PerformanceReview.query.get_or_404(review_id)

    if current_user.role == 'Employee':
        if not current_user.employee or review.employee_id != current_user.employee.id:
            flash('You do not have permission to view this review.', 'error')
            return redirect(url_for('performance.index'))
    elif current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        if review.employee_id not in team_ids and review.reviewer_id != current_user.employee.id:
            flash('You do not have permission to view this review.', 'error')
            return redirect(url_for('performance.index'))

    return render_template('performance/detail.html', review=review)

@bp.route('/review/<int:employee_id>', methods=['GET', 'POST'])
@manager_or_above_required
@login_required
def review(employee_id):
    employee = Employee.query.get_or_404(employee_id)
    
    # Check permission
    if current_user.role == 'Manager':
        if employee.manager_id != current_user.employee.id:
            flash('You do not have permission to review this employee.', 'error')
            return redirect(url_for('performance.index'))
    
    if request.method == 'POST':
        try:
            review_period_start = datetime.strptime(request.form.get('review_period_start'), '%Y-%m-%d').date()
            review_period_end = datetime.strptime(request.form.get('review_period_end'), '%Y-%m-%d').date()
            overall_rating = float(request.form.get('overall_rating', 0))
            feedback = request.form.get('feedback')
            
            # Get goals achieved
            goals_total = Goal.query.filter_by(employee_id=employee_id).count()
            goals_achieved = Goal.query.filter_by(employee_id=employee_id, status='Completed').count()
            
            review = PerformanceReview(
                employee_id=employee_id,
                reviewer_id=current_user.employee.id,
                review_period_start=review_period_start,
                review_period_end=review_period_end,
                overall_rating=overall_rating,
                feedback=feedback,
                goals_achieved=goals_achieved,
                goals_total=goals_total,
                status='Completed'
            )
            
            db.session.add(review)
            db.session.commit()
            
            log_activity(
                user_id=current_user.id,
                action='Performance Review Created',
                entity_type='PerformanceReview',
                entity_id=review.id
            )
            
            flash('Performance review submitted successfully!', 'success')
            return redirect(url_for('performance.index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error creating review: {str(e)}', 'error')
    
    # Get employee's goals
    goals = Goal.query.filter_by(employee_id=employee_id).all()
    
    return render_template('performance/review.html',
                         employee=employee,
                         goals=goals)

@bp.route('/goals')
@login_required
def goals():
    employee_id = request.args.get('employee_id', type=int)
    
    if employee_id:
        if current_user.role == 'Employee' and employee_id != current_user.employee_id:
            flash('You do not have permission to view these goals.', 'error')
            return redirect(url_for('performance.goals'))
        query = Goal.query.filter_by(employee_id=employee_id)
    elif current_user.role == 'Employee' and current_user.employee:
        query = Goal.query.filter_by(employee_id=current_user.employee.id)
    elif current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        query = Goal.query.filter(Goal.employee_id.in_(team_ids))
    else:
        query = Goal.query
    
    goals = query.order_by(Goal.created_at.desc()).all()
    employees = Employee.query.filter_by(status='Active').all()
    
    return render_template('performance/goals.html',
                         goals=goals,
                         employees=employees,
                         selected_employee_id=employee_id)

@bp.route('/goals/add', methods=['POST'])
@login_required
def add_goal():
    employee_id = request.form.get('employee_id')
    
    # Check permission
    if current_user.role == 'Employee' and int(employee_id) != current_user.employee_id:
        flash('You can only create goals for yourself.', 'error')
        return redirect(url_for('performance.goals'))
    
    try:
        goal = Goal(
            employee_id=employee_id,
            title=request.form.get('title'),
            description=request.form.get('description'),
            target_date=datetime.strptime(request.form.get('target_date'), '%Y-%m-%d').date(),
            status='In Progress',
            progress=0
        )
        
        db.session.add(goal)
        db.session.commit()
        
        flash('Goal added successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding goal: {str(e)}', 'error')
    
    return redirect(url_for('performance.goals', employee_id=employee_id))

@bp.route('/goals/<int:id>/update', methods=['POST'])
@login_required
def update_goal(id):
    goal = Goal.query.get_or_404(id)
    
    # Check permission
    if current_user.role == 'Employee' and goal.employee_id != current_user.employee_id:
        flash('You do not have permission to update this goal.', 'error')
        return redirect(url_for('performance.goals'))
    
    try:
        goal.progress = int(request.form.get('progress', 0))
        if goal.progress >= 100:
            goal.status = 'Completed'
        goal.updated_at = datetime.utcnow()
        
        db.session.commit()
        flash('Goal updated successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating goal: {str(e)}', 'error')
    
    return redirect(url_for('performance.goals', employee_id=goal.employee_id))
