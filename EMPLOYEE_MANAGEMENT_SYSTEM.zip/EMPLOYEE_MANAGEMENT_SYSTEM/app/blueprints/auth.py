from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from flask_login import login_user, logout_user, login_required, current_user
from app import db
from app.models import User, Employee, ActivityLog
from app.utils.helpers import log_activity
from datetime import datetime

bp = Blueprint('auth', __name__)

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if not username or not password:
            flash('Please provide both username and password.', 'error')
            return render_template('auth/login.html')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password) and user.is_active:
            login_user(user)
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            log_activity(
                user_id=user.id,
                action='User Login',
                ip_address=request.remote_addr
            )
            
            flash(f'Welcome back, {user.username}!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard.index'))
        else:
            flash('Invalid username or password.', 'error')
    
    return render_template('auth/login.html')

@bp.route('/logout')
@login_required
def logout():
    log_activity(
        user_id=current_user.id,
        action='User Logout',
        ip_address=request.remote_addr
    )
    logout_user()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('auth.login'))

@bp.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        if not current_user.check_password(current_password):
            flash('Current password is incorrect.', 'error')
            return render_template('auth/change_password.html')
        
        if new_password != confirm_password:
            flash('New passwords do not match.', 'error')
            return render_template('auth/change_password.html')
        
        if len(new_password) < 6:
            flash('Password must be at least 6 characters long.', 'error')
            return render_template('auth/change_password.html')
        
        current_user.set_password(new_password)
        db.session.commit()
        
        log_activity(
            user_id=current_user.id,
            action='Password Changed'
        )
        
        flash('Password changed successfully.', 'success')
        return redirect(url_for('dashboard.index'))
    
    return render_template('auth/change_password.html')

@bp.route('/profile')
@login_required
def profile():
    """User's own profile page"""
    employee = current_user.employee if current_user.employee else None
    
    # Get attendance count if employee exists
    attendance_count = 0
    if employee:
        from app.models import Attendance
        attendance_count = Attendance.query.filter_by(employee_id=employee.id).count()
    
    # Get documents if employee exists
    documents = []
    if employee:
        from app.models import Document
        documents = Document.query.filter_by(employee_id=employee.id).all()
    
    return render_template('auth/profile.html',
                         employee=employee,
                         attendance_count=attendance_count,
                         documents=documents)

