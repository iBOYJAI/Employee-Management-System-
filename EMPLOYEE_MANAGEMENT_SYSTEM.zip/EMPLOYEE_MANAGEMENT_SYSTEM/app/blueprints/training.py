from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app import db
from app.models import Training, TrainingAttendee, Employee
from app.utils.helpers import hr_or_admin_required, log_activity
from datetime import datetime

bp = Blueprint('training', __name__)

@bp.route('/')
@login_required
def index():
    page = request.args.get('page', 1, type=int)
    status_filter = request.args.get('status', '', type=str)
    
    query = Training.query
    
    if status_filter:
        query = query.filter_by(status=status_filter)
    
    pagination = query.order_by(Training.start_date.desc()).paginate(
        page=page, per_page=15, error_out=False
    )
    trainings = pagination.items
    
    return render_template('training/index.html',
                         trainings=trainings,
                         pagination=pagination,
                         status_filter=status_filter)

@bp.route('/add', methods=['GET', 'POST'])
@hr_or_admin_required
@login_required
def add():
    if request.method == 'POST':
        try:
            training = Training(
                title=request.form.get('title'),
                description=request.form.get('description'),
                trainer=request.form.get('trainer'),
                start_date=datetime.strptime(request.form.get('start_date'), '%Y-%m-%dT%H:%M'),
                end_date=datetime.strptime(request.form.get('end_date'), '%Y-%m-%dT%H:%M'),
                location=request.form.get('location'),
                max_attendees=int(request.form.get('max_attendees', 0)) if request.form.get('max_attendees') else None,
                status='Scheduled'
            )
            
            db.session.add(training)
            db.session.commit()
            
            log_activity(
                user_id=current_user.id,
                action='Training Created',
                entity_type='Training',
                entity_id=training.id
            )
            
            flash('Training session created successfully!', 'success')
            return redirect(url_for('training.view', id=training.id))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error creating training: {str(e)}', 'error')
    
    return render_template('training/add.html')

@bp.route('/<int:id>')
@login_required
def view(id):
    training = Training.query.get_or_404(id)
    attendees = TrainingAttendee.query.filter_by(training_id=id).all()
    employees = Employee.query.filter_by(status='Active').all()
    
    # Get attendee IDs
    attendee_ids = [a.employee_id for a in attendees]
    
    return render_template('training/view.html',
                         training=training,
                         attendees=attendees,
                         employees=employees,
                         attendee_ids=attendee_ids)

@bp.route('/<int:id>/register', methods=['POST'])
@login_required
def register(id):
    training = Training.query.get_or_404(id)
    
    if not current_user.employee:
        flash('No employee record found.', 'error')
        return redirect(url_for('training.index'))
    
    # Check if already registered
    existing = TrainingAttendee.query.filter_by(
        training_id=id,
        employee_id=current_user.employee.id
    ).first()
    
    if existing:
        flash('You are already registered for this training.', 'info')
        return redirect(url_for('training.view', id=id))
    
    # Check max attendees
    if training.max_attendees:
        current_count = TrainingAttendee.query.filter_by(training_id=id).count()
        if current_count >= training.max_attendees:
            flash('Training session is full.', 'error')
            return redirect(url_for('training.view', id=id))
    
    try:
        attendee = TrainingAttendee(
            training_id=id,
            employee_id=current_user.employee.id,
            status='Registered'
        )
        
        db.session.add(attendee)
        db.session.commit()
        
        flash('Successfully registered for training!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error registering: {str(e)}', 'error')
    
    return redirect(url_for('training.view', id=id))

@bp.route('/<int:training_id>/add-attendee', methods=['POST'])
@hr_or_admin_required
@login_required
def add_attendee(training_id):
    training = Training.query.get_or_404(training_id)
    employee_id = request.form.get('employee_id')
    
    # Check if already registered
    existing = TrainingAttendee.query.filter_by(
        training_id=training_id,
        employee_id=employee_id
    ).first()
    
    if existing:
        flash('Employee is already registered for this training.', 'info')
        return redirect(url_for('training.view', id=training_id))
    
    try:
        attendee = TrainingAttendee(
            training_id=training_id,
            employee_id=employee_id,
            status='Registered'
        )
        
        db.session.add(attendee)
        db.session.commit()
        
        flash('Attendee added successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding attendee: {str(e)}', 'error')
    
    return redirect(url_for('training.view', id=training_id))

@bp.route('/attendee/<int:id>/update-status', methods=['POST'])
@hr_or_admin_required
@login_required
def update_attendee_status(id):
    attendee = TrainingAttendee.query.get_or_404(id)
    
    try:
        attendee.status = request.form.get('status')
        if attendee.status == 'Completed':
            attendee.completion_date = datetime.utcnow()
        
        db.session.commit()
        flash('Attendee status updated successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating status: {str(e)}', 'error')
    
    return redirect(url_for('training.view', id=attendee.training_id))

