from flask import Blueprint, render_template, request, jsonify, send_file
from flask_login import login_required, current_user
from app import db
from app.models import Employee, Department, Attendance, Leave, Payroll
from app.utils.helpers import hr_or_admin_required, manager_or_above_required
from app.utils.pdf_generator import (
    generate_attendance_report_pdf, generate_leave_summary_pdf,
    generate_payroll_summary_pdf, generate_headcount_report_pdf,
    generate_department_analytics_pdf
)
from datetime import datetime, date, timedelta
from sqlalchemy import func
import os

# Get project root directory
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
UPLOADS_DIR = os.path.join(PROJECT_ROOT, 'uploads')

bp = Blueprint('reports', __name__)

@bp.route('/')
@login_required
def index():
    return render_template('reports/index.html')

@bp.route('/headcount')
@manager_or_above_required
@login_required
def headcount():
    # Department-wise headcount
    dept_headcount = db.session.query(
        Department.name,
        func.count(Employee.id).label('count')
    ).join(Employee, Department.id == Employee.department_id, isouter=True)\
     .group_by(Department.id, Department.name).all()
    
    # Role-wise headcount
    role_headcount = db.session.query(
        db.func.count(Employee.id).label('count'),
        Employee.employment_type
    ).group_by(Employee.employment_type).all()
    
    # Status-wise headcount
    status_headcount = db.session.query(
        Employee.status,
        func.count(Employee.id).label('count')
    ).group_by(Employee.status).all()
    
    return render_template('reports/headcount.html',
                         dept_headcount=dept_headcount,
                         role_headcount=role_headcount,
                         status_headcount=status_headcount)

@bp.route('/attendance')
@login_required
def attendance_report():
    start_date = request.args.get('start_date', (date.today() - timedelta(days=30)).strftime('%Y-%m-%d'))
    end_date = request.args.get('end_date', date.today().strftime('%Y-%m-%d'))
    
    query = Attendance.query.filter(
        Attendance.date >= datetime.strptime(start_date, '%Y-%m-%d').date(),
        Attendance.date <= datetime.strptime(end_date, '%Y-%m-%d').date()
    )
    
    # Role-based filtering
    if current_user.role == 'Employee' and current_user.employee:
        query = query.filter_by(employee_id=current_user.employee.id)
    elif current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        query = query.filter(Attendance.employee_id.in_(team_ids))
    
    records = query.all()
    
    # Calculate statistics
    total_days = (datetime.strptime(end_date, '%Y-%m-%d').date() - datetime.strptime(start_date, '%Y-%m-%d').date()).days + 1
    present_count = sum(1 for r in records if r.status == 'Present')
    absent_count = total_days - present_count
    
    return render_template('reports/attendance.html',
                         records=records,
                         start_date=start_date,
                         end_date=end_date,
                         total_days=total_days,
                         present_count=present_count,
                         absent_count=absent_count)

@bp.route('/leave-summary')
@login_required
def leave_summary():
    year = request.args.get('year', date.today().year, type=int)
    
    query = Leave.query.filter(
        func.extract('year', Leave.start_date) == year
    )
    
    # Role-based filtering
    if current_user.role == 'Employee' and current_user.employee:
        query = query.filter_by(employee_id=current_user.employee.id)
    elif current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        query = query.filter(Leave.employee_id.in_(team_ids))
    
    leaves = query.all()
    
    # Summary by status
    status_summary = {}
    for leave in leaves:
        status = leave.status
        if status not in status_summary:
            status_summary[status] = {'count': 0, 'days': 0}
        status_summary[status]['count'] += 1
        status_summary[status]['days'] += leave.days
    
    return render_template('reports/leave_summary.html',
                         leaves=leaves,
                         year=year,
                         status_summary=status_summary)

@bp.route('/payroll-summary')
@hr_or_admin_required
@login_required
def payroll_summary():
    month = request.args.get('month', date.today().month, type=int)
    year = request.args.get('year', date.today().year, type=int)
    
    start_date = date(year, month, 1)
    last_day = (date(year, month + 1, 1) - timedelta(days=1)).day if month < 12 else 31
    end_date = date(year, month, last_day)
    
    payrolls = Payroll.query.filter(
        Payroll.pay_period_start >= start_date,
        Payroll.pay_period_end <= end_date
    ).all()
    
    total_gross = sum(float(p.gross_salary) for p in payrolls)
    total_deductions = sum(float(p.total_deductions) for p in payrolls)
    total_net = sum(float(p.net_salary) for p in payrolls)
    
    return render_template('reports/payroll_summary.html',
                         payrolls=payrolls,
                         month=month,
                         year=year,
                         total_gross=total_gross,
                         total_deductions=total_deductions,
                         total_net=total_net)

@bp.route('/department-analytics')
@hr_or_admin_required
@login_required
def department_analytics():
    departments = Department.query.all()
    
    analytics = []
    for dept in departments:
        employees = Employee.query.filter_by(department_id=dept.id, status='Active').all()
        employee_ids = [e.id for e in employees]
        
        # Attendance stats
        this_month_start = date.today().replace(day=1)
        attendance_count = Attendance.query.filter(
            Attendance.employee_id.in_(employee_ids),
            Attendance.date >= this_month_start
        ).count()
        
        # Leave stats
        pending_leaves = Leave.query.filter(
            Leave.employee_id.in_(employee_ids),
            Leave.status == 'Pending'
        ).count()
        
        analytics.append({
            'department': dept,
            'employee_count': len(employees),
            'attendance_count': attendance_count,
            'pending_leaves': pending_leaves
        })
    
    return render_template('reports/department_analytics.html', analytics=analytics)

# PDF Export Routes
@bp.route('/attendance/pdf')
@login_required
def attendance_report_pdf():
    start_date = request.args.get('start_date', (date.today() - timedelta(days=30)).strftime('%Y-%m-%d'))
    end_date = request.args.get('end_date', date.today().strftime('%Y-%m-%d'))
    
    query = Attendance.query.filter(
        Attendance.date >= datetime.strptime(start_date, '%Y-%m-%d').date(),
        Attendance.date <= datetime.strptime(end_date, '%Y-%m-%d').date()
    )
    
    # Role-based filtering
    if current_user.role == 'Employee' and current_user.employee:
        query = query.filter_by(employee_id=current_user.employee.id)
    elif current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        query = query.filter(Attendance.employee_id.in_(team_ids))
    
    records = query.all()
    
    # Calculate statistics
    total_days = (datetime.strptime(end_date, '%Y-%m-%d').date() - datetime.strptime(start_date, '%Y-%m-%d').date()).days + 1
    present_count = sum(1 for r in records if r.status == 'Present')
    absent_count = total_days - present_count
    attendance_rate = (present_count / total_days * 100) if total_days > 0 else 0
    
    stats = {
        'total_days': total_days,
        'present_count': present_count,
        'absent_count': absent_count,
        'attendance_rate': attendance_rate
    }
    
    # Ensure uploads directory exists
    os.makedirs(UPLOADS_DIR, exist_ok=True)
    output_path = os.path.join(UPLOADS_DIR, f"attendance_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf")
    
    generate_attendance_report_pdf(records, start_date, end_date, stats, output_path)
    
    return send_file(output_path, as_attachment=True, download_name=f"attendance_report_{start_date}_to_{end_date}.pdf")

@bp.route('/leave-summary/pdf')
@login_required
def leave_summary_pdf():
    year = request.args.get('year', date.today().year, type=int)
    
    query = Leave.query.filter(
        func.extract('year', Leave.start_date) == year
    )
    
    # Role-based filtering
    if current_user.role == 'Employee' and current_user.employee:
        query = query.filter_by(employee_id=current_user.employee.id)
    elif current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        query = query.filter(Leave.employee_id.in_(team_ids))
    
    leaves = query.all()
    
    # Summary by status
    status_summary = {}
    for leave in leaves:
        status = leave.status
        if status not in status_summary:
            status_summary[status] = {'count': 0, 'days': 0}
        status_summary[status]['count'] += 1
        status_summary[status]['days'] += leave.days
    
    os.makedirs(UPLOADS_DIR, exist_ok=True)
    output_path = os.path.join(UPLOADS_DIR, f"leave_summary_{year}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf")
    
    generate_leave_summary_pdf(leaves, year, status_summary, output_path)
    
    return send_file(output_path, as_attachment=True, download_name=f"leave_summary_{year}.pdf")

@bp.route('/payroll-summary/pdf')
@hr_or_admin_required
@login_required
def payroll_summary_pdf():
    month = request.args.get('month', date.today().month, type=int)
    year = request.args.get('year', date.today().year, type=int)
    
    start_date = date(year, month, 1)
    last_day = (date(year, month + 1, 1) - timedelta(days=1)).day if month < 12 else 31
    end_date = date(year, month, last_day)
    
    payrolls = Payroll.query.filter(
        Payroll.pay_period_start >= start_date,
        Payroll.pay_period_end <= end_date
    ).all()
    
    total_gross = sum(float(p.gross_salary) for p in payrolls)
    total_deductions = sum(float(p.total_deductions) for p in payrolls)
    total_net = sum(float(p.net_salary) for p in payrolls)
    
    totals = {
        'total_gross': total_gross,
        'total_deductions': total_deductions,
        'total_net': total_net
    }
    
    os.makedirs(UPLOADS_DIR, exist_ok=True)
    output_path = os.path.join(UPLOADS_DIR, f"payroll_summary_{year}_{month:02d}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf")
    
    generate_payroll_summary_pdf(payrolls, month, year, totals, output_path)
    
    return send_file(output_path, as_attachment=True, download_name=f"payroll_summary_{year}_{month:02d}.pdf")

@bp.route('/headcount/pdf')
@hr_or_admin_required
@login_required
def headcount_pdf():
    # Department-wise headcount
    dept_headcount = db.session.query(
        Department.name,
        func.count(Employee.id).label('count')
    ).join(Employee, Department.id == Employee.department_id, isouter=True)\
     .group_by(Department.id, Department.name).all()
    
    # Role-wise headcount
    role_headcount = db.session.query(
        db.func.count(Employee.id).label('count'),
        Employee.employment_type
    ).group_by(Employee.employment_type).all()
    
    # Status-wise headcount
    status_headcount = db.session.query(
        Employee.status,
        func.count(Employee.id).label('count')
    ).group_by(Employee.status).all()
    
    os.makedirs(UPLOADS_DIR, exist_ok=True)
    output_path = os.path.join(UPLOADS_DIR, f"headcount_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf")
    
    generate_headcount_report_pdf(dept_headcount, role_headcount, status_headcount, output_path)
    
    return send_file(output_path, as_attachment=True, download_name="headcount_report.pdf")

@bp.route('/department-analytics/pdf')
@hr_or_admin_required
@login_required
def department_analytics_pdf():
    departments = Department.query.all()
    
    analytics = []
    for dept in departments:
        employees = Employee.query.filter_by(department_id=dept.id, status='Active').all()
        employee_ids = [e.id for e in employees]
        
        # Attendance stats
        this_month_start = date.today().replace(day=1)
        attendance_count = Attendance.query.filter(
            Attendance.employee_id.in_(employee_ids),
            Attendance.date >= this_month_start
        ).count()
        
        # Leave stats
        pending_leaves = Leave.query.filter(
            Leave.employee_id.in_(employee_ids),
            Leave.status == 'Pending'
        ).count()
        
        analytics.append({
            'department': dept,
            'employee_count': len(employees),
            'attendance_count': attendance_count,
            'pending_leaves': pending_leaves
        })
    
    os.makedirs(UPLOADS_DIR, exist_ok=True)
    output_path = os.path.join(UPLOADS_DIR, f"department_analytics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf")
    
    generate_department_analytics_pdf(analytics, output_path)
    
    return send_file(output_path, as_attachment=True, download_name="department_analytics_report.pdf")

