from flask import Blueprint, render_template, jsonify
from flask_login import login_required, current_user
from app import db
from app.models import Employee, Department, Attendance, Leave, Payroll, Notification
from app.utils.helpers import manager_or_above_required
from datetime import datetime, date, timedelta
from sqlalchemy import func, extract

bp = Blueprint('dashboard', __name__)

@bp.route('/')
@login_required
def index():
    # Get KPIs based on user role
    if current_user.role == 'Admin' or current_user.role == 'HR':
        total_employees = Employee.query.filter_by(status='Active').count()
        total_departments = Department.query.count()
        today_attendance = Attendance.query.filter_by(date=date.today()).count()
        pending_leaves = Leave.query.filter_by(status='Pending').count()
        
        # Recent employees
        recent_employees = Employee.query.order_by(Employee.created_at.desc()).limit(5).all()
        
        # Department distribution
        dept_data = db.session.query(
            Department.name,
            func.count(Employee.id).label('count')
        ).join(Employee, Department.id == Employee.department_id, isouter=True)\
         .group_by(Department.id, Department.name).all()
        
        departments = [d[0] for d in dept_data]
        dept_counts = [d[1] for d in dept_data]
        
        # Attendance trend (last 7 days)
        attendance_trend = []
        attendance_labels = []
        for i in range(6, -1, -1):
            day = date.today() - timedelta(days=i)
            count = Attendance.query.filter_by(date=day).count()
            attendance_trend.append(count)
            attendance_labels.append(day.strftime('%m/%d'))
        
    elif current_user.role == 'Manager':
        # Manager sees their team stats
        if current_user.employee and current_user.employee.manager_id:
            team_employees = Employee.query.filter_by(manager_id=current_user.employee.id).all()
            employee_ids = [e.id for e in team_employees]
            
            total_employees = len(team_employees)
            total_departments = 1
            today_attendance = Attendance.query.filter(
                Attendance.employee_id.in_(employee_ids),
                Attendance.date == date.today()
            ).count()
            pending_leaves = Leave.query.filter(
                Leave.employee_id.in_(employee_ids),
                Leave.status == 'Pending'
            ).count()
            
            recent_employees = team_employees[:5]
            departments = [current_user.employee.department.name if current_user.employee.department else 'N/A']
            dept_counts = [total_employees]
            attendance_trend = []
            attendance_labels = []
            for i in range(6, -1, -1):
                day = date.today() - timedelta(days=i)
                count = Attendance.query.filter(
                    Attendance.employee_id.in_(employee_ids),
                    Attendance.date == day
                ).count()
                attendance_trend.append(count)
                attendance_labels.append(day.strftime('%m/%d'))
        else:
            total_employees = total_departments = today_attendance = pending_leaves = 0
            recent_employees = []
            departments = dept_counts = attendance_trend = attendance_labels = []
    else:
        # Employee sees only their own data
        if current_user.employee:
            total_employees = 1
            total_departments = 1
            today_attendance = Attendance.query.filter_by(
                employee_id=current_user.employee.id,
                date=date.today()
            ).count()
            pending_leaves = Leave.query.filter_by(
                employee_id=current_user.employee.id,
                status='Pending'
            ).count()
            recent_employees = [current_user.employee]
            departments = [current_user.employee.department.name if current_user.employee.department else 'N/A']
            dept_counts = [1]
            attendance_trend = []
            attendance_labels = []
            for i in range(6, -1, -1):
                day = date.today() - timedelta(days=i)
                count = Attendance.query.filter_by(
                    employee_id=current_user.employee.id,
                    date=day
                ).count()
                attendance_trend.append(count)
                attendance_labels.append(day.strftime('%m/%d'))
        else:
            total_employees = total_departments = today_attendance = pending_leaves = 0
            recent_employees = []
            departments = dept_counts = attendance_trend = attendance_labels = []
    
    # Get unread notifications count
    unread_notifications = Notification.query.filter_by(
        user_id=current_user.id,
        is_read=False
    ).count()
    
    return render_template('dashboard/index.html',
                         total_employees=total_employees,
                         total_departments=total_departments,
                         today_attendance=today_attendance,
                         pending_leaves=pending_leaves,
                         recent_employees=recent_employees,
                         departments=departments,
                         dept_counts=dept_counts,
                         attendance_trend=attendance_trend,
                         attendance_labels=attendance_labels,
                         unread_notifications=unread_notifications)

@bp.route('/api/stats')
@login_required
def api_stats():
    """API endpoint for dashboard statistics"""
    stats = {
        'total_employees': Employee.query.filter_by(status='Active').count(),
        'total_departments': Department.query.count(),
        'today_attendance': Attendance.query.filter_by(date=date.today()).count(),
        'pending_leaves': Leave.query.filter_by(status='Pending').count()
    }
    return jsonify(stats)

