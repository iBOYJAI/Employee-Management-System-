from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file, jsonify, send_from_directory, current_app, abort
from flask_login import login_required, current_user
from app import db
from app.models import Employee, Department, Role, Document, User, Attendance
from app.utils.helpers import hr_or_admin_required, save_uploaded_file, generate_employee_id, log_activity
from app.utils.excel_export import export_employees_to_excel
from datetime import datetime
import os
from werkzeug.utils import secure_filename

bp = Blueprint('employees', __name__)

@bp.route('/uploads/<path:filename>')
@login_required
def uploaded_file(filename):
    """Serve uploaded files"""
    try:
        upload_folder = current_app.config['UPLOAD_FOLDER']
        # Convert Path object to string if needed
        if hasattr(upload_folder, '__fspath__'):
            upload_folder = str(upload_folder)
        
        # Normalize filename (handle both forward and backslashes)
        # URL paths use forward slashes, convert to OS-specific path
        filename_normalized = filename.replace('\\', '/')
        file_path = os.path.join(upload_folder, filename_normalized.replace('/', os.sep))
        
        # Security check: ensure file is within upload folder
        upload_abs = os.path.abspath(upload_folder)
        file_abs = os.path.abspath(file_path)
        if not file_abs.startswith(upload_abs):
            abort(403)
        
        if os.path.exists(file_path) and os.path.isfile(file_path):
            # Use send_file for direct file serving
            return send_file(file_path, mimetype='image/jpeg' if file_path.lower().endswith(('.jpg', '.jpeg')) else 
                           'image/png' if file_path.lower().endswith(('.png', '.webp')) else 
                           'image/gif' if file_path.lower().endswith('.gif') else None)
        else:
            # Debug: log what we're looking for
            print(f"File not found: {file_path}")
            print(f"Upload folder: {upload_folder}")
            print(f"Requested filename: {filename}")
            # Return default image if file doesn't exist
            return redirect(url_for('static', filename='icons/user.png'))
    except Exception as e:
        print(f"Error serving file {filename}: {e}")
        import traceback
        traceback.print_exc()
        return redirect(url_for('static', filename='icons/user.png'))

@bp.route('/')
@login_required
def index():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '', type=str)
    department_id = request.args.get('department', 0, type=int)
    status_filter = request.args.get('status', '', type=str)
    view_mode = request.args.get('view', 'list', type=str)
    
    query = Employee.query
    
    # Apply filters
    if search:
        query = query.filter(
            db.or_(
                Employee.first_name.ilike(f'%{search}%'),
                Employee.last_name.ilike(f'%{search}%'),
                Employee.email.ilike(f'%{search}%'),
                Employee.employee_id.ilike(f'%{search}%')
            )
        )
    
    if department_id:
        query = query.filter_by(department_id=department_id)
    
    if status_filter:
        query = query.filter_by(status=status_filter)
    
    # Role-based filtering
    if current_user.role == 'Manager' and current_user.employee:
        query = query.filter_by(manager_id=current_user.employee.id)
    elif current_user.role == 'Employee':
        query = query.filter_by(id=current_user.employee.id)
    
    # Hide system admin account from listing
    query = query.filter(Employee.employee_id != 'EMPADMIN0001')

    # Pagination
    pagination = query.order_by(Employee.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    employees = pagination.items
    
    departments = Department.query.all()
    
    return render_template('employees/index.html',
                         employees=employees,
                         pagination=pagination,
                         departments=departments,
                         search=search,
                         department_id=department_id,
                         status_filter=status_filter,
                         view_mode=view_mode)

@bp.route('/add', methods=['GET', 'POST'])
@hr_or_admin_required
@login_required
def add():
    if request.method == 'POST':
        try:
            # Generate employee ID
            emp_id = generate_employee_id()
            
            # Create employee
            employee = Employee(
                employee_id=emp_id,
                first_name=request.form.get('first_name'),
                last_name=request.form.get('last_name'),
                email=request.form.get('email'),
                phone=request.form.get('phone'),
                date_of_birth=datetime.strptime(request.form.get('date_of_birth'), '%Y-%m-%d').date() if request.form.get('date_of_birth') else None,
                gender=request.form.get('gender'),
                address=request.form.get('address'),
                department_id=request.form.get('department_id') or None,
                role_id=request.form.get('role_id') or None,
                manager_id=request.form.get('manager_id') or None,
                hire_date=datetime.strptime(request.form.get('hire_date'), '%Y-%m-%d').date(),
                employment_type=request.form.get('employment_type', 'Full-time'),
                base_salary=float(request.form.get('base_salary', 0)),
                emergency_contact_name=request.form.get('emergency_contact_name'),
                emergency_contact_phone=request.form.get('emergency_contact_phone'),
                emergency_contact_relation=request.form.get('emergency_contact_relation')
            )
            
            # Handle profile picture upload
            if 'profile_picture' in request.files:
                file = request.files['profile_picture']
                if file and file.filename:
                    filepath = save_uploaded_file(file, 'profile_pics')
                    if filepath:
                        employee.profile_picture = filepath
            
            db.session.add(employee)
            db.session.commit()
            
            # Create user account if requested
            if request.form.get('create_user_account') == 'yes':
                username = request.form.get('username')
                password = request.form.get('password')
                role = request.form.get('user_role', 'Employee')
                
                if username and password:
                    user = User(
                        username=username,
                        email=employee.email,
                        employee_id=employee.id,
                        role=role
                    )
                    user.set_password(password)
                    db.session.add(user)
                    db.session.commit()
            
            log_activity(
                user_id=current_user.id,
                action='Employee Created',
                entity_type='Employee',
                entity_id=employee.id,
                details=f"Created employee {employee.employee_id}"
            )
            
            flash('Employee added successfully!', 'success')
            return redirect(url_for('employees.profile', id=employee.id))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding employee: {str(e)}', 'error')
    
    departments = Department.query.all()
    roles = Role.query.all()
    managers = Employee.query.filter_by(status='Active').all()
    
    return render_template('employees/add.html',
                         departments=departments,
                         roles=roles,
                         managers=managers)

@bp.route('/<int:id>')
@login_required
def profile(id):
    employee = Employee.query.get_or_404(id)
    
    # Check access permissions
    if current_user.role == 'Employee' and current_user.employee_id != id:
        flash('You do not have permission to view this profile.', 'error')
        return redirect(url_for('employees.index'))
    
    if current_user.role == 'Manager' and employee.manager_id != current_user.employee_id:
        if current_user.role != 'Admin' and current_user.role != 'HR':
            flash('You do not have permission to view this profile.', 'error')
            return redirect(url_for('employees.index'))
    
    # Get related data
    documents = Document.query.filter_by(employee_id=id).all()
    attendance_count = db.session.query(db.func.count(Attendance.id)).filter_by(employee_id=id).scalar()
    
    return render_template('employees/profile.html',
                         employee=employee,
                         documents=documents,
                         attendance_count=attendance_count)

def _can_manage_documents(target_employee_id):
    if current_user.role in ['Admin', 'HR']:
        return True
    if current_user.role == 'Manager' and current_user.employee:
        team_ids = [e.id for e in Employee.query.filter_by(manager_id=current_user.employee.id).all()]
        return target_employee_id in team_ids
    if current_user.role == 'Employee' and current_user.employee_id == target_employee_id:
        return True
    return False

@bp.route('/<int:id>/documents/upload', methods=['POST'])
@login_required
def upload_document(id):
    employee = Employee.query.get_or_404(id)
    if not _can_manage_documents(employee.id):
        abort(403)

    file = request.files.get('document')
    doc_type = request.form.get('document_type', 'Document')
    name = request.form.get('name') or (file.filename if file else 'Document')

    if not file or not file.filename:
        flash('Please choose a file to upload.', 'error')
        return redirect(url_for('employees.profile', id=id))

    filepath = save_uploaded_file(file, 'documents')
    if not filepath:
        flash('Invalid file type. Allowed: images, pdf, doc, docx.', 'error')
        return redirect(url_for('employees.profile', id=id))

    doc = Document(
        employee_id=employee.id,
        name=name,
        file_path=filepath,
        document_type=doc_type,
        uploaded_by=current_user.employee_id if current_user.employee_id else None
    )
    db.session.add(doc)
    db.session.commit()

    log_activity(
        user_id=current_user.id,
        action='Document Uploaded',
        entity_type='Document',
        entity_id=doc.id,
        details=f'Uploaded {name} for employee {employee.employee_id}'
    )

    flash('Document uploaded successfully.', 'success')
    return redirect(url_for('employees.profile', id=id))

@bp.route('/documents/<int:doc_id>/download')
@login_required
def download_document(doc_id):
    doc = Document.query.get_or_404(doc_id)
    if not _can_manage_documents(doc.employee_id):
        abort(403)

    upload_folder = current_app.config['UPLOAD_FOLDER']
    if hasattr(upload_folder, '__fspath__'):
        upload_folder = str(upload_folder)
    file_path = os.path.join(upload_folder, doc.file_path.replace('/', os.sep))
    if not os.path.exists(file_path):
        flash('File not found.', 'error')
        return redirect(url_for('employees.profile', id=doc.employee_id))
    return send_file(file_path, as_attachment=True, download_name=os.path.basename(file_path))


def _human_size(num):
    for unit in ['B', 'KB', 'MB', 'GB']:
        if num < 1024.0:
            return f"{num:.1f} {unit}"
        num /= 1024.0
    return f"{num:.1f} TB"


def _build_tree(base_path):
    tree = []
    for entry in sorted(os.listdir(base_path)):
        if entry.startswith('.'):
            continue
        full_path = os.path.join(base_path, entry)
        if os.path.isdir(full_path):
            tree.append({
                'name': entry,
                'type': 'dir',
                'children': _build_tree(full_path)
            })
        else:
            stat = os.stat(full_path)
            tree.append({
                'name': entry,
                'type': 'file',
                'path': os.path.relpath(full_path, base_path).replace('\\', '/'),
                'size': _human_size(stat.st_size),
                'mtime': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M')
            })
    return tree


@bp.app_template_global()
def loop_tree(node):
    if node.get('type') == 'dir':
        children = ''.join([loop_tree(child) for child in node.get('children', [])])
        return f"<li class='tree-item tree-folder'><span class='pill folder-pill'></span>{node['name']}<ul>{children}</ul></li>"
    download = url_for('employees.download_upload', filepath=node.get('path', ''))
    size = node.get('size', '')
    mtime = node.get('mtime', '')
    meta = f"<span class='meta'>{size} • {mtime}</span>" if size or mtime else ''
    return f"<li class='tree-item tree-file'><span class='pill file-pill'></span><a href='{download}' target='_blank'>{node['name']}</a> {meta}</li>"


@bp.route('/uploads-browser')
@hr_or_admin_required
@login_required
def uploads_browser():
    upload_folder = current_app.config['UPLOAD_FOLDER']
    if hasattr(upload_folder, '__fspath__'):
        upload_folder = str(upload_folder)
    tree = _build_tree(upload_folder) if os.path.exists(upload_folder) else []
    return render_template('uploads/browse.html', tree=tree)


@bp.route('/uploads/download/<path:filepath>')
@hr_or_admin_required
@login_required
def download_upload(filepath):
    upload_folder = current_app.config['UPLOAD_FOLDER']
    if hasattr(upload_folder, '__fspath__'):
        upload_folder = str(upload_folder)
    safe_path = filepath.replace('..', '').replace('\\', '/')
    file_path = os.path.join(upload_folder, safe_path)
    if not os.path.commonprefix([os.path.abspath(file_path), os.path.abspath(upload_folder)]) == os.path.abspath(upload_folder):
        abort(403)
    if not os.path.exists(file_path):
        abort(404)
    return send_file(file_path, as_attachment=True, download_name=os.path.basename(file_path))

@bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@hr_or_admin_required
@login_required
def edit(id):
    employee = Employee.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            employee.first_name = request.form.get('first_name')
            employee.last_name = request.form.get('last_name')
            employee.email = request.form.get('email')
            employee.phone = request.form.get('phone')
            if request.form.get('date_of_birth'):
                employee.date_of_birth = datetime.strptime(request.form.get('date_of_birth'), '%Y-%m-%d').date()
            employee.gender = request.form.get('gender')
            employee.address = request.form.get('address')
            employee.department_id = request.form.get('department_id') or None
            employee.role_id = request.form.get('role_id') or None
            employee.manager_id = request.form.get('manager_id') or None
            if request.form.get('hire_date'):
                employee.hire_date = datetime.strptime(request.form.get('hire_date'), '%Y-%m-%d').date()
            employee.employment_type = request.form.get('employment_type')
            employee.status = request.form.get('status')
            employee.base_salary = float(request.form.get('base_salary', 0))
            employee.emergency_contact_name = request.form.get('emergency_contact_name')
            employee.emergency_contact_phone = request.form.get('emergency_contact_phone')
            employee.emergency_contact_relation = request.form.get('emergency_contact_relation')
            
            # Handle profile picture upload
            if 'profile_picture' in request.files:
                file = request.files['profile_picture']
                if file and file.filename:
                    # Delete old profile picture if exists
                    if employee.profile_picture:
                        upload_folder = current_app.config['UPLOAD_FOLDER']
                        # Convert Path object to string if needed
                        if hasattr(upload_folder, '__fspath__'):
                            upload_folder = str(upload_folder)
                        old_path = os.path.join(upload_folder, employee.profile_picture.replace('/', os.sep))
                        if os.path.exists(old_path):
                            try:
                                os.remove(old_path)
                            except Exception as e:
                                print(f"Error deleting old profile picture: {e}")
                    
                    filepath = save_uploaded_file(file, 'profile_pics')
                    if filepath:
                        employee.profile_picture = filepath
                        flash('Profile picture updated successfully!', 'success')
                    else:
                        flash('Failed to upload profile picture. Please check file format (JPG, PNG, GIF).', 'error')
            
            db.session.commit()
            
            log_activity(
                user_id=current_user.id,
                action='Employee Updated',
                entity_type='Employee',
                entity_id=employee.id
            )
            
            flash('Employee updated successfully!', 'success')
            return redirect(url_for('employees.profile', id=employee.id))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating employee: {str(e)}', 'error')
    
    departments = Department.query.all()
    roles = Role.query.all()
    managers = Employee.query.filter_by(status='Active').all()
    
    return render_template('employees/edit.html',
                         employee=employee,
                         departments=departments,
                         roles=roles,
                         managers=managers)

@bp.route('/export')
@hr_or_admin_required
@login_required
def export():
    employees = Employee.query.all()
    output_path = os.path.join('uploads', 'employees_export.xlsx')
    export_employees_to_excel(employees, output_path)
    return send_file(output_path, as_attachment=True, download_name='employees.xlsx')

@bp.route('/api/search')
@login_required
def api_search():
    query = request.args.get('q', '')
    employees = Employee.query.filter(
        db.or_(
            Employee.first_name.ilike(f'%{query}%'),
            Employee.last_name.ilike(f'%{query}%'),
            Employee.employee_id.ilike(f'%{query}%')
        )
    ).limit(10).all()
    
    results = [{
        'id': emp.id,
        'employee_id': emp.employee_id,
        'name': emp.full_name,
        'email': emp.email
    } for emp in employees]
    
    return jsonify(results)

