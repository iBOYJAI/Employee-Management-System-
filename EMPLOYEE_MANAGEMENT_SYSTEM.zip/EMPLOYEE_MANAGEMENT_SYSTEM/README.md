# Employee Management System

Modern HR suite built with Flask + SQLAlchemy + MySQL. Modules include auth, employees, attendance, leaves, payroll, performance, assets, training, notifications, and reports.

## Stack & Requirements
- Python 3.11+  
- MySQL 8.x (XAMPP MySQL works fine)  
- Node is **not** required; front-end is vanilla HTML/CSS/JS.

## Quick Start (Windows + XAMPP)
1) Install Python packages offline  
`python scripts/install_offline.py`
2) Start MySQL in XAMPP (ensure port 3306 is free).
3) Create the database  
   - Create DB `employee_management` and import `db/employee_management.sql`, **or**  
   - Set your own creds in `.env`/`config.py` and let the app create tables.
4) (Optional) Seed demo data  
`python scripts/seed_data.py`
5) Run the app  
`python run.py` then open `http://localhost:5000`

### Default Logins (after seeding)
- Admin: `admin` / `admin123`
- HR: `sarah.johnson` / `password123`
- Manager: `john.smith` / `password123`
- Employee: `michael.brown` / `password123`

## Configuration
`config.py` reads environment variables when present:
- `SECRET_KEY`
- `MYSQL_HOST`, `MYSQL_USER`, `MYSQL_PASSWORD`, `MYSQL_DATABASE`
- `UPLOAD_FOLDER`, `MAX_CONTENT_LENGTH`, `ALLOWED_EXTENSIONS`
- Pagination/session options

Example `.env`:
```
SECRET_KEY=change-me
MYSQL_HOST=localhost
MYSQL_USER=root
MYSQL_PASSWORD=
MYSQL_DATABASE=employee_management
FLASK_ENV=development
```

## Project Map
```
EMPLOYEE_MANAGEMENT_SYSTEM/
 app/             # App factory, blueprints, models, utils
 templates/       # HTML templates
 static/          # CSS, JS, icons, fonts
 packages/        # Offline wheels
 uploads/         # User uploads
 db/              # MySQL schema dump
 scripts/         # Install/seed/verify helpers
 docs/            # Setup + reference docs
 config.py        # Base configuration
 run.py           # Entry point
```

## Key Scripts
- `scripts/install_offline.py` — install dependencies from `packages/`
- `scripts/download_dependencies.py` — fetch wheels when online
- `scripts/download_assets.py` — fetch front-end assets if missing
- `scripts/seed_data.py` — seed demo users/employees and sample HR data
- `scripts/verify_setup.py` — sanity checks for env, DB, and assets
- `scripts/prepare_for_copy.py` — bundle for offline transfer

## Features
- Role-based authentication (Admin, HR, Manager, Employee)
- Employees, departments, roles, reporting lines
- Attendance tracking and calendars
- Leave management with approvals
- Payroll with earnings/deductions and PDF/Excel outputs
- Performance goals, reviews, and training sessions
- Asset assignments and notifications
- Reports and dashboards (PDF/Excel exports)

## Common Tasks
- Change pagination/session or upload limits: edit `config.py`
- Add a new module/page: create a blueprint in `app/blueprints/` plus template
- Export reports: use the UI; generated files land in `uploads/`
- Reset demo data: rerun `python scripts/seed_data.py`

## Troubleshooting
- MySQL connection refused: start MySQL (XAMPP), confirm port 3306, and verify `MYSQL_*` values in `.env`/`config.py`.
- Missing packages: rerun `python scripts/install_offline.py`.
- Port in use: change the port in `run.py` or free the conflicting process.

