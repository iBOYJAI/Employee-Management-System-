// Main JavaScript file for Employee Management System

// Sidebar Toggle
document.addEventListener('DOMContentLoaded', function() {
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
            if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('active');
            }
        }
    });
    
    // Auto-hide flash messages
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 300);
        }, 5000);
    });
    
    // Modal handling
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        const closeBtn = modal.querySelector('.modal-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                modal.classList.remove('active');
            });
        }
        
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    });
    
    // Form validation
    const forms = document.querySelectorAll('form[method="POST"]');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
});

// Utility Functions
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type}`;
    toast.innerHTML = `<span>${message}</span><button class="close" onclick="this.parentElement.remove()">×</button>`;
    
    const container = document.querySelector('.flash-messages') || document.body;
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// AJAX Helper
async function fetchJSON(url, options = {}) {
    try {
        const response = await fetch(url, {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Fetch error:', error);
        throw error;
    }
}

// Check-in/Check-out functions
async function checkIn() {
    const btnIn = document.getElementById('btnCheckIn');
    const btnOut = document.getElementById('btnCheckOut');
    const warn = document.getElementById('empLinkWarning');
    if (btnIn) btnIn.disabled = true;
    if (btnOut) btnOut.disabled = true;
    if (warn) warn.style.display = 'inline-block';
    try {
        const response = await fetchJSON('/attendance/check-in', {
            method: 'POST'
        });
        
        if (response.success) {
            showToast('Checked in successfully!', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(response.message || 'Error checking in', 'error');
        }
    } catch (error) {
        showToast('Error checking in', 'error');
    } finally {
        if (btnIn) btnIn.disabled = false;
        if (btnOut) btnOut.disabled = false;
        if (warn) warn.style.display = 'none';
    }
}

async function checkOut() {
    const btnIn = document.getElementById('btnCheckIn');
    const btnOut = document.getElementById('btnCheckOut');
    const warn = document.getElementById('empLinkWarning');
    if (btnIn) btnIn.disabled = true;
    if (btnOut) btnOut.disabled = true;
    if (warn) warn.style.display = 'inline-block';
    try {
        const response = await fetchJSON('/attendance/check-out', {
            method: 'POST'
        });
        
        if (response.success) {
            showToast(`Checked out successfully! Hours worked: ${response.hours}`, 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(response.message || 'Error checking out', 'error');
        }
    } catch (error) {
        showToast('Error checking out', 'error');
    } finally {
        if (btnIn) btnIn.disabled = false;
        if (btnOut) btnOut.disabled = false;
        if (warn) warn.style.display = 'none';
    }
}

// Notification functions
async function markNotificationRead(id) {
    try {
        await fetchJSON(`/notifications/mark-read/${id}`, {
            method: 'POST'
        });
        document.getElementById(`notification-${id}`).classList.add('read');
    } catch (error) {
        console.error('Error marking notification as read:', error);
    }
}

async function markAllNotificationsRead() {
    try {
        await fetchJSON('/notifications/mark-all-read', {
            method: 'POST'
        });
        location.reload();
    } catch (error) {
        console.error('Error marking all notifications as read:', error);
    }
}

// Export to CSV (simple implementation)
function exportToCSV(data, filename) {
    const csv = data.map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
}

// User dropdown toggle
function toggleUserMenu() {
    const menu = document.getElementById('userMenu');
    const dropdown = document.getElementById('userDropdown');
    const arrow = document.getElementById('dropdownArrow');
    
    if (menu && dropdown) {
        const isActive = menu.classList.contains('active');
        
        // Close all other dropdowns
        document.querySelectorAll('.user-menu.active').forEach(m => {
            if (m !== menu) {
                m.classList.remove('active');
            }
        });
        
        // Toggle current menu
        if (isActive) {
            menu.classList.remove('active');
            if (arrow) arrow.style.transform = 'rotate(0deg)';
        } else {
            menu.classList.add('active');
            if (arrow) arrow.style.transform = 'rotate(180deg)';
        }
    }
}

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const menu = document.getElementById('userMenu');
    const dropdown = document.getElementById('userDropdown');
    
    if (menu && dropdown && !menu.contains(event.target)) {
        menu.classList.remove('active');
        const arrow = document.getElementById('dropdownArrow');
        if (arrow) arrow.style.transform = 'rotate(0deg)';
    }
});

// Close dropdown when clicking on a link
document.addEventListener('DOMContentLoaded', function() {
    const dropdownLinks = document.querySelectorAll('.user-dropdown a');
    dropdownLinks.forEach(link => {
        link.addEventListener('click', function() {
            const menu = document.getElementById('userMenu');
            if (menu) {
                menu.classList.remove('active');
                const arrow = document.getElementById('dropdownArrow');
                if (arrow) arrow.style.transform = 'rotate(0deg)';
            }
        });
    });
});

