-- Employee Management System Database Schema
-- MySQL Database for XAMPP
-- Import this file into phpMyAdmin or MySQL command line

CREATE DATABASE IF NOT EXISTS employee_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE employee_management;

-- Users table for authentication
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'Employee',
    employee_id INT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    last_login DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Departments table
CREATE TABLE IF NOT EXISTS departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT NULL,
    manager_id INT NULL,
    budget DECIMAL(12,2) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Roles table
CREATE TABLE IF NOT EXISTS roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Employees table
CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id VARCHAR(20) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    phone VARCHAR(20) NULL,
    date_of_birth DATE NULL,
    gender VARCHAR(10) NULL,
    address TEXT NULL,
    profile_picture VARCHAR(255) NULL,
    department_id INT NULL,
    role_id INT NULL,
    manager_id INT NULL,
    hire_date DATE NOT NULL,
    employment_type VARCHAR(20) DEFAULT 'Full-time',
    status VARCHAR(20) DEFAULT 'Active',
    base_salary DECIMAL(12,2) NOT NULL DEFAULT 0,
    currency VARCHAR(10) DEFAULT 'INR',
    emergency_contact_name VARCHAR(100) NULL,
    emergency_contact_phone VARCHAR(20) NULL,
    emergency_contact_relation VARCHAR(50) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_employee_id (employee_id),
    INDEX idx_email (email),
    INDEX idx_department (department_id),
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE SET NULL,
    FOREIGN KEY (manager_id) REFERENCES employees(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Update users table foreign key
ALTER TABLE users ADD FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL;
ALTER TABLE departments ADD FOREIGN KEY (manager_id) REFERENCES employees(id) ON DELETE SET NULL;

-- Attendance table
CREATE TABLE IF NOT EXISTS attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    date DATE NOT NULL,
    check_in TIME NULL,
    check_out TIME NULL,
    hours_worked DECIMAL(5,2) NULL,
    status VARCHAR(20) DEFAULT 'Present',
    notes TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_date (date),
    INDEX idx_employee (employee_id),
    UNIQUE KEY unique_employee_date (employee_id, date),
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Leave types table
CREATE TABLE IF NOT EXISTS leave_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    max_days INT NOT NULL DEFAULT 0,
    is_paid BOOLEAN DEFAULT TRUE,
    description TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Leaves table
CREATE TABLE IF NOT EXISTS leaves (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days INT NOT NULL,
    reason TEXT NULL,
    status VARCHAR(20) DEFAULT 'Pending',
    approved_by INT NULL,
    approved_at DATETIME NULL,
    rejection_reason TEXT NULL,
    applied_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_employee (employee_id),
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(id) ON DELETE RESTRICT,
    FOREIGN KEY (approved_by) REFERENCES employees(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payroll table
CREATE TABLE IF NOT EXISTS payroll (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    pay_period_start DATE NOT NULL,
    pay_period_end DATE NOT NULL,
    pay_date DATE NOT NULL,
    base_salary DECIMAL(12,2) NOT NULL,
    gross_salary DECIMAL(12,2) NOT NULL,
    total_deductions DECIMAL(12,2) NOT NULL DEFAULT 0,
    net_salary DECIMAL(12,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'Pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_employee (employee_id),
    INDEX idx_status (status),
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payroll items table
CREATE TABLE IF NOT EXISTS payroll_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    payroll_id INT NOT NULL,
    item_type VARCHAR(20) NOT NULL,
    name VARCHAR(100) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (payroll_id) REFERENCES payroll(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Performance reviews table
CREATE TABLE IF NOT EXISTS performance_reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    reviewer_id INT NOT NULL,
    review_period_start DATE NOT NULL,
    review_period_end DATE NOT NULL,
    overall_rating DECIMAL(3,2) NULL,
    feedback TEXT NULL,
    goals_achieved INT DEFAULT 0,
    goals_total INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'Draft',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_employee (employee_id),
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (reviewer_id) REFERENCES employees(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Goals table
CREATE TABLE IF NOT EXISTS goals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NULL,
    target_date DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'In Progress',
    progress INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_employee (employee_id),
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Trainings table
CREATE TABLE IF NOT EXISTS trainings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NULL,
    trainer VARCHAR(100) NULL,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    location VARCHAR(200) NULL,
    max_attendees INT NULL,
    status VARCHAR(20) DEFAULT 'Scheduled',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Training attendees table
CREATE TABLE IF NOT EXISTS training_attendees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    training_id INT NOT NULL,
    employee_id INT NOT NULL,
    status VARCHAR(20) DEFAULT 'Registered',
    completion_date DATETIME NULL,
    feedback TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_training_employee (training_id, employee_id),
    FOREIGN KEY (training_id) REFERENCES trainings(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Assets table
CREATE TABLE IF NOT EXISTS assets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    brand VARCHAR(100) NULL,
    model VARCHAR(100) NULL,
    serial_number VARCHAR(100) NULL,
    purchase_date DATE NULL,
    purchase_cost DECIMAL(12,2) NULL,
    status VARCHAR(20) DEFAULT 'Available',
    notes TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_asset_code (asset_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Asset assignments table
CREATE TABLE IF NOT EXISTS asset_assignment (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    employee_id INT NOT NULL,
    assigned_date DATE NOT NULL,
    return_date DATE NULL,
    assigned_by INT NULL,
    notes TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_employee (employee_id),
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_by) REFERENCES employees(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) NOT NULL,
    link VARCHAR(255) NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_read (is_read),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Documents table
CREATE TABLE IF NOT EXISTS documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    name VARCHAR(200) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    document_type VARCHAR(50) NOT NULL,
    uploaded_by INT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_employee (employee_id),
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by) REFERENCES employees(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Activity logs table
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NULL,
    entity_id INT NULL,
    details TEXT NULL,
    ip_address VARCHAR(45) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_created (created_at),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Settings table
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    `key` VARCHAR(100) NOT NULL UNIQUE,
    value TEXT NULL,
    description TEXT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default data
INSERT INTO roles (name, description) VALUES
('Head of Engineering', 'Leads engineering and platform delivery'),
('HR Business Partner', 'People operations and compliance'),
('Delivery Manager', 'Project delivery and client success'),
('Senior Software Engineer', 'Builds and maintains applications'),
('QA Engineer', 'Quality assurance and release readiness'),
('Accountant', 'Finance, payroll, and reconciliations'),
('Administrator', 'System administrator');

INSERT INTO departments (name, description) VALUES
('IT', 'Information Technology Department'),
('HR', 'Human Resources Department'),
('Operations', 'Operations and Delivery'),
('Finance', 'Finance and Accounting');

INSERT INTO leave_types (name, max_days, is_paid, description) VALUES
('Annual Leave', 20, TRUE, 'Annual vacation leave'),
('Sick Leave', 10, TRUE, 'Medical leave'),
('Personal Leave', 5, FALSE, 'Personal time off'),
('Maternity Leave', 90, TRUE, 'Maternity leave'),
('Paternity Leave', 7, TRUE, 'Paternity leave'),
('Emergency Leave', 3, FALSE, 'Emergency situations');

INSERT INTO settings (`key`, value, description) VALUES
('company_name', 'Kaveri Corp', 'Company name'),
('company_address', 'No. 21, Mount Road, Chennai, Tamil Nadu 600002', 'Company address'),
('company_phone', '+91-44-4000-1234', 'Company phone number'),
('company_email', 'hello@kavericorp.in', 'Company email'),
('fiscal_year_start', '2025-04-01', 'Fiscal year start date'),
('working_hours_per_day', '8', 'Standard working hours per day'),
('tax_rate', '0.15', 'Default tax rate (15%)');

-- Demo employees (Tamil Nadu–style sample data)
INSERT INTO employees (
    id,
    employee_id,
    first_name,
    last_name,
    email,
    phone,
    date_of_birth,
    gender,
    address,
    profile_picture,
    department_id,
    role_id,
    manager_id,
    hire_date,
    employment_type,
    status,
    base_salary,
    currency,
    emergency_contact_name,
    emergency_contact_phone,
    emergency_contact_relation
) VALUES
(1, 'EMP-TN-0001', 'Sundar', 'Raman', 'sundar.raman@kavericorp.in', '+91-97890-10001', '1984-08-12', 'Male', 'T Nagar, Chennai, TN', NULL, 1, 1, NULL, '2023-01-01', 'Full-time', 'Active', 140000, 'INR', 'Raji Raman', '+91-97890-20001', 'Spouse'),
(2, 'EMP-TN-0002', 'Vaishnavi', 'Krishnan', 'vaishnavi.krishnan@kavericorp.in', '+91-97890-10002', '1988-02-20', 'Female', 'Velachery, Chennai, TN', NULL, 2, 2, 1, '2023-02-01', 'Full-time', 'Active', 105000, 'INR', 'Karthik Krishnan', '+91-97890-20002', 'Spouse'),
(3, 'EMP-TN-0003', 'Arun', 'Kumar', 'arun.kumar@kavericorp.in', '+91-97890-10003', '1986-05-05', 'Male', 'Peelamedu, Coimbatore, TN', NULL, 3, 3, 1, '2023-03-01', 'Full-time', 'Active', 118000, 'INR', 'Sangeetha Kumar', '+91-97890-20003', 'Spouse'),
(4, 'EMP-TN-0004', 'Meena', 'Iyer', 'meena.iyer@kavericorp.in', '+91-97890-10004', '1990-11-18', 'Female', 'Anna Nagar, Chennai, TN', NULL, 1, 4, 3, '2023-04-15', 'Full-time', 'Active', 92000, 'INR', 'Lakshmi Iyer', '+91-97890-20004', 'Mother'),
(5, 'EMP-TN-0005', 'Prakash', 'Muthu', 'prakash.muthu@kavericorp.in', '+91-97890-10005', '1992-09-02', 'Male', 'Saravanampatti, Coimbatore, TN', NULL, 1, 5, 3, '2023-05-10', 'Full-time', 'Active', 78000, 'INR', 'Muthuvel', '+91-97890-20005', 'Father'),
(6, 'EMP-TN-0006', 'Naveen', 'Subramani', 'naveen.subramani@kavericorp.in', '+91-97890-10006', '1991-01-27', 'Male', 'Adyar, Chennai, TN', NULL, 4, 6, 2, '2023-06-20', 'Full-time', 'Active', 83000, 'INR', 'Subramani', '+91-97890-20006', 'Father');

-- Demo users (password hash generated via Werkzeug generate_password_hash)
INSERT INTO users (username, email, password_hash, role, employee_id, is_active) VALUES
('admin', 'admin@company.com', 'scrypt:32768:8:1$mrqk0KSgf0iAXH3y$f818047228a9da0bc334f6e8f28a4b150fe2dfa985f9182ab5e09da29d8acca02013198a45b1d6eba6a053743dcbc7479786572e31379c18ecc031442d9bb73c', 'Admin', NULL, TRUE),
('sundar.raman', 'sundar.raman@kavericorp.in', 'scrypt:32768:8:1$mrqk0KSgf0iAXH3y$f818047228a9da0bc334f6e8f28a4b150fe2dfa985f9182ab5e09da29d8acca02013198a45b1d6eba6a053743dcbc7479786572e31379c18ecc031442d9bb73c', 'Admin', 1, TRUE),
('vaishnavi.krishnan', 'vaishnavi.krishnan@kavericorp.in', 'scrypt:32768:8:1$Hu3uK5cQf3oPWwtM$d423a570c7a6f29ab988604c0192c224c2e4323eef9e1053877cb014203fa4b91e318f0167edb1836866506a7197ac492fc18d9b84d287b64390663ba90fb658', 'HR', 2, TRUE),
('arun.kumar', 'arun.kumar@kavericorp.in', 'scrypt:32768:8:1$Hu3uK5cQf3oPWwtM$d423a570c7a6f29ab988604c0192c224c2e4323eef9e1053877cb014203fa4b91e318f0167edb1836866506a7197ac492fc18d9b84d287b64390663ba90fb658', 'Manager', 3, TRUE),
('meena.iyer', 'meena.iyer@kavericorp.in', 'scrypt:32768:8:1$Hu3uK5cQf3oPWwtM$d423a570c7a6f29ab988604c0192c224c2e4323eef9e1053877cb014203fa4b91e318f0167edb1836866506a7197ac492fc18d9b84d287b64390663ba90fb658', 'Employee', 4, TRUE),
('prakash.muthu', 'prakash.muthu@kavericorp.in', 'scrypt:32768:8:1$Hu3uK5cQf3oPWwtM$d423a570c7a6f29ab988604c0192c224c2e4323eef9e1053877cb014203fa4b91e318f0167edb1836866506a7197ac492fc18d9b84d287b64390663ba90fb658', 'Employee', 5, TRUE),
('naveen.subramani', 'naveen.subramani@kavericorp.in', 'scrypt:32768:8:1$Hu3uK5cQf3oPWwtM$d423a570c7a6f29ab988604c0192c224c2e4323eef9e1053877cb014203fa4b91e318f0167edb1836866506a7197ac492fc18d9b84d287b64390663ba90fb658', 'Employee', 6, TRUE);


