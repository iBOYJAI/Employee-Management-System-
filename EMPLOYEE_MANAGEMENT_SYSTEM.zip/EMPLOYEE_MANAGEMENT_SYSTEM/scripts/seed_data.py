"""
Seed the Employee Management System with demo data.

Creates tables (if missing), default settings, an admin, demo users/employees,
and lightweight attendance/leave/payroll/performance/notification samples.
"""

from datetime import date, datetime, timedelta

from sqlalchemy import text
from sqlalchemy.exc import OperationalError

from app import create_app, db
from app.models import (
    ActivityLog,
    Attendance,
    Department,
    Employee,
    Goal,
    Leave,
    LeaveType,
    Notification,
    Payroll,
    PayrollItem,
    PerformanceReview,
    Role,
    Setting,
    User,
)


app = create_app()


def verify_db_connection() -> None:
    """Fail fast with a clear hint when MySQL is unreachable."""
    try:
        db.session.execute(text("SELECT 1"))
    except OperationalError as exc:
        print("\n[Database] Unable to connect to MySQL.")
        print("Tips: ensure MySQL is running (XAMPP),")
        print("      confirm host/user/password/database in config.py or .env,")
        print("      and that port 3306 is open.")
        print(f"Original error: {exc}\n")
        raise SystemExit(1)


def create_tables():
    """Create core tables plus defaults for departments, roles, leave types, and settings."""
    db.create_all()

    if Department.query.count() == 0:
        departments = [
            Department(name="IT", description="Information Technology Department"),
            Department(name="HR", description="Human Resources Department"),
            Department(name="Finance", description="Finance and Accounting Department"),
            Department(name="Operations", description="Operations Department"),
            Department(name="Sales", description="Sales and Marketing Department"),
        ]
        db.session.add_all(departments)

    if Role.query.count() == 0:
        roles = [
            Role(name="Software Developer", description="Develops and maintains software applications"),
            Role(name="HR Manager", description="Manages human resources operations"),
            Role(name="Project Manager", description="Manages projects and teams"),
            Role(name="Accountant", description="Handles financial records and payroll"),
            Role(name="Administrator", description="System administrator"),
        ]
        db.session.add_all(roles)

    if LeaveType.query.count() == 0:
        leave_types = [
            LeaveType(name="Annual Leave", max_days=20, is_paid=True, description="Annual vacation leave"),
            LeaveType(name="Sick Leave", max_days=10, is_paid=True, description="Medical leave"),
            LeaveType(name="Personal Leave", max_days=5, is_paid=False, description="Personal time off"),
            LeaveType(name="Maternity Leave", max_days=90, is_paid=True, description="Maternity leave"),
            LeaveType(name="Paternity Leave", max_days=7, is_paid=True, description="Paternity leave"),
            LeaveType(name="Emergency Leave", max_days=3, is_paid=False, description="Emergency situations"),
        ]
        db.session.add_all(leave_types)

    if Setting.query.count() == 0:
        settings = [
            Setting(key="company_name", value="Employee Management System", description="Company name"),
            Setting(key="company_address", value="123 Business Street, City, Country", description="Company address"),
            Setting(key="company_phone", value="+1-234-567-8900", description="Company phone number"),
            Setting(key="company_email", value="info@company.com", description="Company email"),
            Setting(key="fiscal_year_start", value="2024-01-01", description="Fiscal year start date"),
            Setting(key="working_hours_per_day", value="8", description="Standard working hours per day"),
            Setting(key="tax_rate", value="0.15", description="Default tax rate (15%)"),
        ]
        db.session.add_all(settings)

    db.session.commit()


def ensure_default_admin():
    """Ensure a default admin user exists with known credentials and an employee profile."""
    admin = User.query.filter_by(username="admin").first()
    dept = Department.query.filter_by(name="IT").first() or Department(
        name="IT", description="Information Technology Department"
    )
    role = Role.query.filter_by(name="Administrator").first() or Role(
        name="Administrator", description="System administrator"
    )
    if dept.id is None:
        db.session.add(dept)
        db.session.flush()
    if role.id is None:
        db.session.add(role)
        db.session.flush()

    if not admin:
        admin = User(username="admin", email="admin@company.com", role="Admin", is_active=True)
        admin.set_password("admin123")
        db.session.add(admin)
        db.session.flush()
    else:
        admin.email = admin.email or "admin@company.com"
        admin.role = "Admin"
        admin.is_active = True
        admin.set_password("admin123")
        db.session.flush()

    if not admin.employee:
        employee = Employee(
            employee_id="EMPADMIN0001",
            first_name="System",
            last_name="Administrator",
            email=admin.email,
            department_id=dept.id,
            role_id=role.id,
            hire_date=date(2023, 1, 1),
            employment_type="Full-time",
            status="Active",
            base_salary=90000,
            currency="INR",
        )
        db.session.add(employee)
        db.session.flush()
        admin.employee_id = employee.id

    db.session.commit()


def ensure_demo_users():
    """Create/reset demo HR/Manager/Employee users with known credentials (TN-flavored sample data)."""
    demos = [
        ("sundar.raman", "sundar.raman@kavericorp.in", "Admin"),
        ("vaishnavi.krishnan", "vaishnavi.krishnan@kavericorp.in", "HR"),
        ("arun.kumar", "arun.kumar@kavericorp.in", "Manager"),
        ("meena.iyer", "meena.iyer@kavericorp.in", "Employee"),
        ("prakash.muthu", "prakash.muthu@kavericorp.in", "Employee"),
        ("naveen.subramani", "naveen.subramani@kavericorp.in", "Employee"),
    ]
    for username, email, role in demos:
        user = User.query.filter_by(username=username).first()
        if not user:
            user = User(username=username, email=email, role=role, is_active=True)
            user.set_password("password123")
            db.session.add(user)
        else:
            user.email = user.email or email
            user.role = role
            user.is_active = True
            user.set_password("password123")
    db.session.commit()


def ensure_demo_employees():
    """Create demo employee profiles (TN-style names/roles) and link them to demo users."""
    dept_by_name = {d.name: d for d in Department.query.all()}
    role_by_name = {r.name: r for r in Role.query.all()}

    def get_or_create_dept(name, desc=""):
        dept = dept_by_name.get(name)
        if not dept:
            dept = Department(name=name, description=desc)
            db.session.add(dept)
            db.session.flush()
            dept_by_name[name] = dept
        return dept

    def get_or_create_role(name, desc=""):
        role = role_by_name.get(name)
        if not role:
            role = Role(name=name, description=desc)
            db.session.add(role)
            db.session.flush()
            role_by_name[name] = role
        return role

    demos = [
        # username, code, first, last, dept, role, manager_username, salary, phone, address, emergency_name, emergency_phone, emergency_relation
        (
            "sundar.raman",
            "EMP-TN-0001",
            "Sundar",
            "Raman",
            "IT",
            "Head of Engineering",
            None,
            140000,
            "+91-97890-10001",
            "T Nagar, Chennai, TN",
            "Raji Raman",
            "+91-97890-20001",
            "Spouse",
        ),
        (
            "vaishnavi.krishnan",
            "EMP-TN-0002",
            "Vaishnavi",
            "Krishnan",
            "HR",
            "HR Business Partner",
            "sundar.raman",
            105000,
            "+91-97890-10002",
            "Velachery, Chennai, TN",
            "Karthik Krishnan",
            "+91-97890-20002",
            "Spouse",
        ),
        (
            "arun.kumar",
            "EMP-TN-0003",
            "Arun",
            "Kumar",
            "Operations",
            "Delivery Manager",
            "sundar.raman",
            118000,
            "+91-97890-10003",
            "Peelamedu, Coimbatore, TN",
            "Sangeetha Kumar",
            "+91-97890-20003",
            "Spouse",
        ),
        (
            "meena.iyer",
            "EMP-TN-0004",
            "Meena",
            "Iyer",
            "IT",
            "Senior Software Engineer",
            "arun.kumar",
            92000,
            "+91-97890-10004",
            "Anna Nagar, Chennai, TN",
            "Lakshmi Iyer",
            "+91-97890-20004",
            "Mother",
        ),
        (
            "prakash.muthu",
            "EMP-TN-0005",
            "Prakash",
            "Muthu",
            "IT",
            "QA Engineer",
            "arun.kumar",
            78000,
            "+91-97890-10005",
            "Saravanampatti, Coimbatore, TN",
            "Muthuvel",
            "+91-97890-20005",
            "Father",
        ),
        (
            "naveen.subramani",
            "EMP-TN-0006",
            "Naveen",
            "Subramani",
            "Finance",
            "Accountant",
            "vaishnavi.krishnan",
            83000,
            "+91-97890-10006",
            "Adyar, Chennai, TN",
            "Subramani",
            "+91-97890-20006",
            "Father",
        ),
    ]

    created = {}
    for username, emp_code, first, last, dept_name, role_name, manager_username, salary, phone, address, emg_name, emg_phone, emg_rel in demos:
        user = User.query.filter_by(username=username).first()
        employee = Employee.query.filter_by(employee_id=emp_code).first()
        dept = get_or_create_dept(dept_name, f"{dept_name} Department")
        role = get_or_create_role(role_name, role_name)

        if not employee:
            employee = Employee(
                employee_id=emp_code,
                first_name=first,
                last_name=last,
                email=user.email if user else f"{username}@company.com",
                phone=phone,
                department_id=dept.id,
                role_id=role.id,
                hire_date=date(2023, 1, 15),
                employment_type="Full-time",
                status="Active",
                base_salary=salary,
                currency="INR",
                address=address,
                emergency_contact_name=emg_name,
                emergency_contact_phone=emg_phone,
                emergency_contact_relation=emg_rel,
            )
            db.session.add(employee)
            db.session.flush()

        created[username] = employee
        if user:
            user.employee_id = employee.id
            user.role = user.role or role_name
            user.is_active = True
            user.email = user.email or f"{username}@company.com"

    db.session.commit()

    for username, _, _, _, _, _, manager_username, _ in demos:
        if manager_username and manager_username in created and username in created:
            created[username].manager_id = created[manager_username].id
    db.session.commit()


def seed_mock_data():
    """Seed lightweight attendance, leave, payroll, performance, and notifications."""
    employees = Employee.query.all()
    if not employees:
        return

    today = date.today()

    for emp in employees:
        for i in range(5):
            day = today - timedelta(days=i)
            existing = Attendance.query.filter_by(employee_id=emp.id, date=day).first()
            if not existing:
                att = Attendance(
                    employee_id=emp.id,
                    date=day,
                    check_in=datetime(day.year, day.month, day.day, 9, 0).time(),
                    check_out=datetime(day.year, day.month, day.day, 17, 30).time(),
                    hours_worked=8.5,
                    status="Present",
                )
                db.session.add(att)

    leave_type = LeaveType.query.first()
    if employees and leave_type:
        for emp in employees[:2]:
            existing_leave = Leave.query.filter_by(employee_id=emp.id).first()
            if not existing_leave:
                start = today + timedelta(days=3)
                end = start + timedelta(days=2)
                leave = Leave(
                    employee_id=emp.id,
                    leave_type_id=leave_type.id,
                    start_date=start,
                    end_date=end,
                    days=3,
                    reason="Family function (kalyanam) – planned leave",
                    status="Approved",
                    approved_by=emp.id,
                    approved_at=datetime.utcnow(),
                )
                db.session.add(leave)

    for emp in employees:
        for offset in range(0, 2):
            month = today.month - offset
            year = today.year
            if month <= 0:
                month += 12
                year -= 1
            start = date(year, month, 1)
            next_month = date(year + (month // 12), (month % 12) + 1, 1)
            end = next_month - timedelta(days=1)

            existing_payroll = Payroll.query.filter_by(
                employee_id=emp.id, pay_period_start=start, pay_period_end=end
            ).first()
            if not existing_payroll:
                base_salary = float(emp.base_salary or 60000)
                tax_rate = 0.15
                tax_amount = base_salary * tax_rate
                payroll = Payroll(
                    employee_id=emp.id,
                    pay_period_start=start,
                    pay_period_end=end,
                    pay_date=today,
                    base_salary=base_salary,
                    gross_salary=base_salary,
                    total_deductions=tax_amount,
                    net_salary=base_salary - tax_amount,
                    status="Processed",
                )
                db.session.add(payroll)
                db.session.flush()
                db.session.add(
                    PayrollItem(
                        payroll_id=payroll.id,
                        item_type="Earning",
                        name="Base Salary",
                        amount=base_salary,
                    )
                )
                db.session.add(
                    PayrollItem(
                        payroll_id=payroll.id,
                        item_type="Deduction",
                        name="Income Tax",
                        amount=tax_amount,
                    )
                )

    db.session.commit()

    sample_feedback = [
        "Strong sprint delivery, keeps the team synced.",
        "Great stakeholder updates; tighten on release notes.",
        "QA caught edge cases ahead of UAT—nice save.",
        "Finance books closed on time with clean reconciliations.",
    ]

    for idx, emp in enumerate(employees[:4]):
        reviewer = emp.manager or employees[0]
        pr_existing = PerformanceReview.query.filter_by(employee_id=emp.id).first()
        if not pr_existing:
            pr = PerformanceReview(
                employee_id=emp.id,
                reviewer_id=reviewer.id if reviewer else emp.id,
                review_period_start=date(today.year, today.month, 1),
                review_period_end=today,
                overall_rating=4.2 - (0.1 * idx),
                feedback=sample_feedback[idx % len(sample_feedback)],
                goals_achieved=3,
                goals_total=4,
                status="Completed",
            )
            db.session.add(pr)
        goal_existing = Goal.query.filter_by(employee_id=emp.id).first()
        if not goal_existing:
            g = Goal(
                employee_id=emp.id,
                title="Ship reliable releases",
                description="Reduce production bugs by 30% and improve rollback playbooks (no sev1).",
                target_date=today + timedelta(days=90),
                status="In Progress",
                progress=40,
            )
            db.session.add(g)

    for emp in employees[:4]:
        if emp.user_account:
            user_obj = emp.user_account[0] if hasattr(emp.user_account, "__iter__") else emp.user_account
            existing_note = Notification.query.filter_by(user_id=user_obj.id).first()
            if not existing_note:
                note = Notification(
                    user_id=user_obj.id,
                    title="Vaanga! Welcome",
                    message="EMS ready. Please punch-in, see goals, and update status. Nandri!",
                    type="info",
                    link="/dashboard",
                )
                db.session.add(note)

    db.session.commit()


def main():
    with app.app_context():
        print("→ Checking database connection...")
        verify_db_connection()

        print("→ Creating tables and defaults...")
        create_tables()

        print("→ Ensuring admin and demo users...")
        ensure_default_admin()
        ensure_demo_users()
        ensure_demo_employees()

        print("→ Seeding sample HR data...")
        seed_mock_data()

        print("\nSeeding complete. You can log in with the default credentials listed in README.md.\n")


if __name__ == "__main__":
    main()

